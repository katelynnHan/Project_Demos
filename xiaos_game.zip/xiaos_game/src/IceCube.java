import javafx.scene.image.Image;

public class IceCube extends Item {
	private Item item;
	private boolean melted;

	public IceCube(Item i) {
		super("Ice Cube", "Looks like there's something inside the ice");
		item = i;

		String path = getClass().getResource("Resource/iceCube.png").toString();

		setImage(new Image(path, 40, 40, true, true));
		updateViewImage(path);
	}

	public void usedOn(Item i) { // when character selects an item to use
		if (i.isTorch()) {
			House r = (House) getWorld();
			r.getPlayableCharacter().getInventory().remove(r.getPlayableCharacter().getInventory().getSelectedItem());
			melted = true;
			
			setName("Puddle of Water");

			String path = getClass().getResource("Resource/puddleOfWater.png").toString();
			updateViewImage(path, 250, 250);
			setText("The ice cube turned into a puddle of water,", "and was an item inside!", "");
			getViewSprite().setX(getWorld().getPrefWidth()/2 - getViewSprite().getImage().getWidth()/2);
		} else if (!i.isTorch()) {
			super.usedOn(i);
		}
	}

	@Override
	public void removeDisplay() {
		super.removeDisplay();

		House r = (House)getWorld();
		
		if (melted) {
			item.setX(this.getX());
			item.setY(this.getY());

			r.getCurrentRoom().add(item);

			r.getCurrentRoom().remove(this);
			r.putPlayerOntop();
		}
	}
}
