import java.util.ArrayList;

public class Recipe { //for food
	private ArrayList<Item> foods;
	private ArrayList<String> names;
	private Item result;
	
	public Recipe(Item finalDish, Item ...foodItems) {
		foods = new ArrayList<Item>();
		names = new ArrayList<String>();
		
		for(Item s : foodItems) {
			foods.add(s);
			names.add(s.getName());
		}
		
		result = finalDish;
	}
	
	public boolean contains(Item name) {
		return foods.contains(name);
	}
	
	public boolean contains(String name) {
		return names.contains(name);
	}
	
	public int size() {
		return names.size();
	}
	
	public Item getResult() {
		return result;
	}
	
	public void remove(Item i) {
		foods.remove(i);
	}
	
	public void remove(String name) {
		names.remove(name);
	}
}
