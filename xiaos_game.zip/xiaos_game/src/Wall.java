import engine.Actor;
import javafx.scene.image.Image;

public class Wall extends Actor {
	private Image img;
	private boolean isLeft;
	private boolean isBottom;
	private boolean isTop;
	private boolean isRight;
	private boolean isVertical;
	
	public Wall(boolean vertical) {
		isLeft = false;
		isBottom = false;
		isTop = false;
		isRight = false;
		
		String path = "hi";
		
		isVertical = vertical;
		
		if(vertical) {
			path = getClass().getResource("Resource/wallVertical.png").toString();
			img = new Image(path, 30, 500, true, true);
		}else {
			path = getClass().getResource("Resource/wallHorizontal.png").toString();
			img = new Image(path, 500, 30, true, true);
		}
		
		setImage(img);
	}
	
	@Override
	public void act(long now) {
		
	}
	
	public boolean isLeft() {
		return isLeft;
	}
	
	public boolean isRight() {
		return isRight;
	}
	
	public boolean isBottom() {
		return isBottom;
	}
	
	public boolean isTop() {
		return isTop;
	}
	
	public void setIsTop(boolean t) {
		isTop = t;
	}
	
	public void setIsLeft(boolean l) {
		isLeft = l;
	}
	
	public void setIsBottom(boolean b) {
		isBottom = b;
	}
	
	public void setIsRight(boolean r) {
		isRight = r;
	}
}
