import engine.World;
import javafx.scene.image.Image;

public class Room9Object extends RoomObject {

	public Room9Object(World w) {
		super(w);
		// TODO Auto-generated constructor stub
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}

	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();

		House h = (House) getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		Item leaf = new Item("Leaf", "This place could do with some greenery");
		String leafPath = getClass().getResource("Resource/leaf.png").toString();
		leaf.setImage(new Image(leafPath, 50, 50, true, true));
		leaf.updateViewImage(leafPath);
		
		WordPuzzle pz = new WordPuzzle("NATURAL", "Locked Box", "ANOTHER BOX??? SO NOT natural!!!", leaf);
		
		IceCube ice = new IceCube(pz);
		ice.setX(370);
		ice.setY(160);
		
		Item sweetFlower = new Item("Sweet Flower", "A pretty flower, and sweet too!");
		String flowerPath = getClass().getResource("Resource/sweetFlower.png").toString();
		sweetFlower.setImage(new Image(flowerPath, 50, 50, true, true));
		sweetFlower.updateViewImage(flowerPath);

		Item sugarPile = new Item("Sugar Pile", "");
		Recipe sweetFlowerRec = new Recipe(sweetFlower, sugarPile, leaf);

		Item sweetMadame = new Item("Sweet Madame", "Crispy and tender (with a touch of sweet!)");
		String madamePath = getClass().getResource("Resource/sweetMadame.png").toString();
		sweetMadame.setImage(new Image(madamePath, 50, 50, true, true));
		sweetMadame.updateViewImage(madamePath);
		Item chicken = new Item("Chicken", "");
		Recipe sweetMadameRec = new Recipe(sweetMadame, sweetFlower, chicken);

		Item iron = new Item("Iron", "");
		String ironPath = getClass().getResource("Resource/iron.png").toString();
		iron.setImage(new Image(ironPath, 50, 50, true, true));
		iron.updateViewImage(ironPath);
		iron.setX(50);
		iron.setY(50);
		
		WordPuzzle pzz = new WordPuzzle("FORGING", "Locked Box", "You can use the thing inside for FORGING", iron);
		pzz.setX(170);
		pzz.setY(150);
		
		GettableItem hammer = new GettableItem("Hammer", "Used to forge things");
		String hammerPath = getClass().getResource("Resource/hammer.png").toString();
		hammer.setImage(new Image(hammerPath, 50, 50, true, true));
		hammer.updateViewImage(hammerPath);
		hammer.setX(350);
		hammer.setY(280);
		
		Key key = new Key();
		Recipe keyRec = new Recipe(key, iron, hammer);

		Item almondTofu = new Item("Almond Tofu", "Xiao's favorite food");
		String tofuPath = getClass().getResource("Resource/almondTofu.png").toString();
		almondTofu.setImage(new Image(tofuPath, 50, 50, true, true));
		almondTofu.updateViewImage(tofuPath);

		Item milk = new Item("Milk", "Gives you strong bones!");
		Item sugar = new Item("Sugar", "");
		
		Item almonds = new Item("Almonds", "");
		Recipe almondTofuRec = new Recipe(almondTofu, almonds, milk, sugar);

		CookingPot pot = new CookingPot(almondTofuRec, keyRec, sweetMadameRec, sweetFlowerRec);
		pot.setX(100);
		pot.setY(250);
		
		Bone b1 = new Bone("This one looks crusty...");
		b1.setX(50);
		b1.setY(30);
		Bone b2 = new Bone("This has maggots crawling on it!!!(EW EW EW)");
		b2.setX(50);
		b2.setY(170);
		Bone b3 = new Bone("This one looks pretty new...");
		b3.setX(400);
		b3.setY(250);
		
		Book xiaosDiary = new Book("Tattered Diary", "There are some pages torn out",
				"6/1/XXXX", "", "",
				"Another one came in today. She's a", 
				"young woman dressed in purple.", "",
				"Her soul seems pure but I don't think", 
				"she's the one.", "",
				"6/3/XXXX", "", "",
				"A small child came in today.", "","", 
				"I always feel uncomfortable whenever",
				"I see children here.", "",
				"They're so young, how did they...", "","",
				"...ah forget it.", "", "",
				"6/5/XXXX", "", "",
				"The purple lady and the child still", 
				"haven't tried to pass the test, I,", 
				"wonder why...",
				"Is it that they pity me? Or is it", 
				"because they simply don't want to",
				"go to the underlands?",
				"6/9/XXXX","","", 
				"Lisa's birthday is coming up.","","",
				"I can't really cook but apparently", 
				"she really likes cuisine from her home",
				"country.");
		
		xiaosDiary.setX(370);
		xiaosDiary.setY(110);
		
		String bedPath = getClass().getResource("Resource/bigBed.png").toString();
		Item bed = new Item("Bed", "So comfy and soft!", bedPath, 100, 100);
		bed.setX(480 - bed.getImage().getWidth());
		bed.setY(20);
		
		String plantPath = getClass().getResource("Resource/longPlant.png").toString();
		Item plant = new Item("Tall Plant", "Almost as tall as me!", plantPath, 60, 60);
		plant.setX(480 - bed.getImage().getWidth() - plant.getImage().getWidth());
		plant.setY(5);
		
		String checkPath = getClass().getResource("Resource/checkeredCarpet.png").toString();
		Item carpet = new Item("", "", checkPath, 100, 100);
		carpet.setExaminable(false);
		carpet.setX(20);
		carpet.setY(355 - carpet.getImage().getHeight());
		
		String foxyPath = getClass().getResource("Resource/foxy.png").toString();
		Item foxy = new Item("Plushie", "It's a pirate fox! Arghhh!", foxyPath, 40, 40);
		foxy.setX(20);
		foxy.setY(310);
		
		String bonniePath = getClass().getResource("Resource/bonnie.png").toString();
		Item bonnie = new Item("Plushie", "Awww what a cute bunny!", bonniePath, 40, 40);
		bonnie.setX(60);
		bonnie.setY(300);
		
		String dogPath = getClass().getResource("Resource/tanDogSleep.png").toString();
		Item dog = new Item("Dog", "WAIT IS THAT A DOG OMG SO CUTE", dogPath, 30, 30);
		dog.setX(90);
		dog.setY(320);
		
		//Decor
		add(carpet);
		add(foxy);
		add(bonnie);
		add(dog);
		
		add(plant);
		add(bed);
		add(xiaosDiary);
		
		//Functionality
		add(b1);
		add(b2);
		add(b3);
		add(ice);
		add(pot);
		add(hammer);
		add(pzz);
	}
}
