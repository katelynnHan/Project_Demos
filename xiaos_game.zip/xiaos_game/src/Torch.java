import javafx.scene.image.Image;

public class Torch extends GettableItem{
	public Torch() {
		super("Torch", "Don't touch it you'll burn yourself!");
		
		String path = getClass().getResource("Resource/torch.png").toString();
		setImage(new Image(path, 40, 40, true, true));
		updateViewImage(path);
		
		setIsTorch(true);
	}
}
