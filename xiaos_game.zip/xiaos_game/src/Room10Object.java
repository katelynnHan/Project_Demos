import engine.World;
import javafx.scene.image.Image;

public class Room10Object extends RoomObject {

	public Room10Object(World w) {
		super(w);
		// TODO Auto-generated constructor stub
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}

	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		Key key = new Key();
		
		Torch torch = new Torch();
		torch.setX(100);
		torch.setY(100);
		
		Item sweetFlower = new Item("Sweet Flower", "A pretty flower, and sweet too!");
		String flowerPath = getClass().getResource("Resource/sweetFlower.png").toString();
		sweetFlower.setImage(new Image(flowerPath, 50, 50, true, true));
		sweetFlower.updateViewImage(flowerPath);
		
		Item leaf = new Item("Leaf", "");

		Item sugarPile = new Item("Sugar Pile", "");
		
		Recipe sweetFlowerRec = new Recipe(sweetFlower, sugarPile, leaf);

		Item sweetMadame = new Item("Sweet Madame", "Crispy and tender (with a touch of sweet!)");
		String madamePath = getClass().getResource("Resource/sweetMadame.png").toString();
		sweetMadame.setImage(new Image(madamePath, 50, 50, true, true));
		sweetMadame.updateViewImage(madamePath);
		Item chicken = new Item("Chicken", "");
		Recipe sweetMadameRec = new Recipe(sweetMadame, sweetFlower, chicken);

		Item iron = new Item("Iron", "");
		
		Item hammer = new Item("Hammer", "Used to forge things");
		String hammerPath = getClass().getResource("Resource/hammer.png").toString();
		hammer.setImage(new Image(hammerPath, 50, 50, true, true));
		hammer.updateViewImage(hammerPath);
		
		Recipe keyRec = new Recipe(key, iron, hammer);

		GettableItem milk = new GettableItem("Milk", "Gives you strong bones!");
		String milkPath = getClass().getResource("Resource/milk.png").toString();
		milk.setImage(new Image(milkPath, 50, 50, true, true));
		milk.updateViewImage(milkPath);
		milk.setX(380);
		milk.setY(255);
		
		Item almondTofu = new Item("Almond Tofu", "Xiao's favorite food");
		String tofuPath = getClass().getResource("Resource/almondTofu.png").toString();
		almondTofu.setImage(new Image(tofuPath, 50, 50, true, true));
		almondTofu.updateViewImage(tofuPath);

		Item almonds = new Item("Almonds", "");
		
		Item sugar = new Item("Sugar", "The best seasoning!");
		String sugarPath = getClass().getResource("Resource/sugar.png").toString();
		sugar.setImage(new Image(sugarPath, 40, 40, true, true));
		sugar.updateViewImage(sugarPath);
		
		Recipe almondTofuRec = new Recipe(almondTofu, almonds, milk, sugar);

		CookingPot pot = new CookingPot(almondTofuRec, keyRec, sweetMadameRec, sweetFlowerRec);
		pot.setX(70);
		pot.setY(260);
		
		Person xiao = new Person("Xiao", almondTofu, key);
		String xiaoPath = getClass().getResource("Resource/xiaoAngy.png").toString();
		xiao.setImage(new Image(xiaoPath, 100, 100, true, true));
		xiao.updateViewImage(xiaoPath);
		xiao.setX(getWorld().getPrefWidth()/2 - xiao.getImage().getWidth() * 0.75);
		xiao.setY(70);
		
		xiao.setHungryText("So we finally meet...", "", "",
				"I was the one leaving those notes", 
				"for you, I am x.", "",
				"You must be suspicious of why there", 
				"are so many bones around here right?", "", 
				"Those are the remains of those that",
				"came before you.","",
				"The cauldron deemed all of them to be", 
				"unworthy of going to the upperlands.","", 
				"That's why they weren't able to create", 
				"the almond tofu.", "",
				"This is not some regular house,", 
				"you could say that it's the",
				"afterlife.", 
				"Notice how you're all just bones?", "", "", 
				"To get out of here, you need to", 
				"prove that your soul is pure and", 
				"that you can create a truly", 
				"delicious almond tofu.", "", "",
				"I'll be here waiting.");
		
		xiao.setFullText("I...", "", "",
				"...", "", "",
				"I never thought that one day I", 
				"could meet someone like you...", "",
				"Someone who could make a truly", 
				"delicious almond tofu", "",
				"...", "", "",
				"I'm finally free", "", "", 
				"I don't have to guard this", 
				"door anymore.", "",
				"Thank you...", "", "", 
				"Go on now, you have the key,",
				"Go to the upperlands...", "",
				"This is where we part ways.", "", "",
				"Goodbye.","","",
				"You say you want to save me?","","",
				"...","","",
				"Hmph, I can't understand you humans","","",
				"Well then come back for me when you've",
				"setteled","",
				"I'll be waiting.");
		
		WordPuzzle pz = new WordPuzzle("GENSHIN", "Locked Box", "Last one I swear!", sugar);
		pz.setX(400);
		pz.setY(100);
		
		PieceOfPaper last = new PieceOfPaper("The final word puzzle is the game", 
				"that’s super popular right now and", 
				"that these characters are from", 
				"(yes this is breaking the 4th wall)");
		last.setX(40);
		last.setY(120);
		
		PieceOfPaper recipe = new PieceOfPaper("Recipe for Almond Tofu", "", "",
				"Region: Liyue", "", "", 
				"Materials:", 
				"- Almonds", 
				"- Milk", 
				"- Sugar", "", "",
				"It's the only thing I can stomach.", 
				"The taste of Almond Tofu feels like",
				"a fond dream.");
		
		Bone b1 = new Bone("A musty bone");
		b1.setX(40);
		b1.setY(80);
		Bone b2 = new Bone("Sheesh this bone is really long");
		b2.setX(80);
		b2.setY(200);
		Bone b3 = new Bone("Why are there so many bones???");
		b3.setX(300);
		b3.setY(60);
		Bone b4 = new Bone("Does x not clean his room???");
		b4.setX(370);
		b4.setY(300);
		Bone b5 = new Bone("Lisa's room doesn't have ANY bones");
		b5.setX(140);
		b5.setY(150);
		
		String brownPath = getClass().getResource("Resource/brownCarpet.png").toString();
		Item brownCarp = new Item("","", brownPath, 100, 100);
		brownCarp.setExaminable(false);
		brownCarp.setX(20);
		brownCarp.setY(355 - brownCarp.getImage().getHeight());
		
		//Decor
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(brownCarp);
		
		//Functionality
		add(last);
		add(milk);
		add(pz);
		add(torch);
		add(xiao);
		add(pot);
	}
}
