import engine.World;
import javafx.scene.image.Image;

public class Room8Object extends RoomObject {
	public Room8Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}

	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();

		House h = (House) getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);

		Key key = new Key();
		IceCube ice = new IceCube(key);
		ice.setX(400);
		ice.setY(300);

		GettableItem sugarPile = new GettableItem("Sugar Pile", "A pile of sugar!");
		String sPath = getClass().getResource("Resource/sugarPile.png").toString();
		sugarPile.setImage(new Image(sPath, 30, 30, true, true));
		sugarPile.updateViewImage(sPath);
		sugarPile.setX(90);
		sugarPile.setY(140);

		// Cooking pot recipes
		Item leaf = new Item("Leaf", "Some greenery would look nice here");

		Item sweetFlower = new Item("Sweet Flower", "A pretty flower, and sweet too!");
		String flowerPath = getClass().getResource("Resource/sweetFlower.png").toString();
		sweetFlower.setImage(new Image(flowerPath, 50, 50, true, true));
		sweetFlower.updateViewImage(flowerPath);

		Recipe sweetFlowerRec = new Recipe(sweetFlower, sugarPile, leaf);

		Item sweetMadame = new Item("Sweet Madame", "Crispy and tender (with a touch of sweet!)");
		String madamePath = getClass().getResource("Resource/sweetMadame.png").toString();
		sweetMadame.setImage(new Image(madamePath, 50, 50, true, true));
		sweetMadame.updateViewImage(madamePath);
		Item chicken = new Item("Chicken", "");
		Recipe sweetMadameRec = new Recipe(sweetMadame, sweetFlower, chicken);

		Item iron = new Item("Iron", "");
		
		Item hammer = new Item("Hammer", "Used to forge things");
		
		Recipe keyRec = new Recipe(key, iron, hammer);

		Item almondTofu = new Item("Almond Tofu", "Xiao's favorite food");
		String tofuPath = getClass().getResource("Resource/almondTofu.png").toString();
		almondTofu.setImage(new Image(tofuPath, 50, 50, true, true));
		almondTofu.updateViewImage(tofuPath);

		Item milk = new Item("Milk", "Gives you strong bones!");
		
		Item sugar = new Item("Sugar", "");

		Item almonds = new Item("Almonds", "");
		Recipe almondTofuRec = new Recipe(almondTofu, almonds, milk, sugar);

		CookingPot pot = new CookingPot(almondTofuRec, keyRec, sweetMadameRec, sweetFlowerRec);
		pot.setX(170);
		pot.setY(150);
		
		Book otherDiary = new Book("Leather Journal", "An old leather journal",
				"I don’t know what fate awaits me.","","", 
				"I don't know how to cook!","","", 
				"How am I ever going to pass this test?", "","",
				"I can feel my soul crumbling, am I", 
				"going to end up like one of those bones",
				"on the ground?");
		otherDiary.setX(90);
		otherDiary.setY(80);
		
		Book manual = new Book("Albedo's Guide to All Mondstadtian Plantlife", "A plant manual",
				"Sweet flower in all simplicity is", 
				"just an absurd amount of sugar", 
				"infused into a plant.",
				"It's easily recreatable using alchemy", 
				"if one has sugar and a plant of some sort.");
		manual.setX(30);
		manual.setY(110);
		
		String bedPath = getClass().getResource("Resource/bigBed.png").toString();
		Item bed = new Item("Bed", "So comfy and soft!", bedPath, 100, 100);
		bed.setX(480 - bed.getImage().getWidth());
		bed.setY(20);
		
		String wardrobePath = getClass().getResource("Resource/wardrobe.png").toString();
		Item wardrobe = new Item("Wardrobe", "Filled with pretty clothes!", wardrobePath, 80, 80);
		wardrobe.setX(480 - bed.getImage().getWidth() - wardrobe.getImage().getWidth());
		wardrobe.setY(10);
		
		String redPath = getClass().getResource("Resource/redCarpet.png").toString();
		Item redCarp = new Item("","", redPath, 150, 150);
		redCarp.setExaminable(false);
		redCarp.setX(20);
		redCarp.setY(20);
		
		String standPath = getClass().getResource("Resource/stand.png").toString();
		Item stand = new Item("Drawer", "Ooo I wonder what those novels ontop are about", standPath, 80, 80);
		stand.setX(30);
		stand.setY(20);
		
		String plantPath = getClass().getResource("Resource/smallPlantOneLeaf.png").toString();
		Item plant = new Item("Small potted plant", "OMGOMGOMG SO CUTE AND TINY AHHHH", plantPath, 30, 30);
		plant.setX(35);
		plant.setY(10);
		
		String pilePath = getClass().getResource("Resource/pileOfClothes.png").toString();
		Item pileOfClothes = new Item("Pile of Clothes", "This person should really clean their room", pilePath, 50, 50);
		pileOfClothes.setX(370);
		pileOfClothes.setY(90);
		
		String freddyPath = getClass().getResource("Resource/freddy.png").toString();
		Item freddy = new Item("Plushie", "You bop the nose and it makes a cute noise", freddyPath, 30, 30);
		freddy.setX(110);
		freddy.setY(30);
		
		//Decor
		add(bed);
		add(wardrobe);
		add(pileOfClothes);
		add(redCarp);
		add(freddy);
		add(stand);
		add(plant);
		add(manual);
		add(otherDiary);
		
		//Functionality
		add(pot);
		add(ice);
		add(sugarPile);
	}
}
