import engine.Actor;

public class WordBlock extends Actor {

	public WordBlock(String[] words) {
		
	}
	
	
	@Override
	public void act(long now) {
		// TODO Auto-generated method stub
		
	}
	

}
