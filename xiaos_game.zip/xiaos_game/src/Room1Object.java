import engine.World;
import javafx.scene.image.Image;

public class Room1Object extends RoomObject {
	private PieceOfPaper paper;
	private IceCube ice;
	private GettableItem torch;
	private Item key;
	private CookingPot pot;
	private Recipe onigiriRec;

	public Room1Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}
	
	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		key = new Key();
		key.setX(200);
		key.setY(200);
		
		paper = new PieceOfPaper("Hello and welcome to my house, you can call",
				 "me x. You can rely on my notes for",
				 "information.",
				 "Your goal here is to make it to the",
				 "10th room where you will find me.", "",
				 "Some items in this world can be",
				 "obtained by clicking on them, try with the",
				 "key object.",
				 "You can open up your inventory by",
				 "pressing TAB and closing it with ‘C.’", "",
				 "When you’re examining an object, open", 
				 "inventory and select an object to use with",
				 "your mouse.", 
				 "When you’re next to a door, press Enter",
				 "to go through it.", "",
				 "- x"); 
		paper.setX(100);
		paper.setY(100);
		
		add(paper);
		add(key);
	}
}
