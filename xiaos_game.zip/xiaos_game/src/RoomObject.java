import java.util.ArrayList;

import engine.World;
import javafx.scene.Node;

public class RoomObject {
	private ArrayList<Node> objects;

	private World world;

	private Door entrance;
	private Door exit;

	private boolean visited;

	public RoomObject(World w) {
		objects = new ArrayList<Node>();
		world = w;
		visited = false;
	}

	public World getWorld() {
		return world;
	}

	public void add(Node n) {
		objects.add(n);
		getWorld().getChildren().add(n);
	}

	public void remove(Node n) {
		objects.remove(n);
		getWorld().getChildren().remove(n);
	}

	public void addAllObjects() {
		if (!visited) {
			addAllObjectsNonVisitedVer();
		} else if (visited) {
			addAllObjectsVisitedVer();
		}
	}

	public void addAllObjectsNonVisitedVer() {
		House r = (House) getWorld();

		if (r.getRoomNumber() <= 10) {
			entrance = new Door();
			entrance.setX(getWorld().getPrefWidth() / 2 - entrance.getWidth() / 2);
			entrance.setIsNextRoom(true);

			exit = new Door();
			exit.setX(getWorld().getPrefWidth() / 2 - exit.getWidth() / 2);
			exit.setY(getWorld().getHeight() - exit.getHeight());
			exit.setIsLocked(false);

			add(entrance);
			
			if (r.getRoomNumber() > 1) {
				add(exit);
			}
		}
	}

	public void addAllObjectsVisitedVer() {
		for (int i = 0; i < objects.size(); i++) {
			getWorld().getChildren().add(objects.get(i));
		}
	}

	public void removeAllObjects() {
		for (int i = 0; i < objects.size(); i++) {
			getWorld().getChildren().remove(objects.get(i));
		}
	}

	public Door getEntrance() {
		return entrance;
	}

	public Door getExit() {
		return exit;
	}

	public boolean visited() {
		return visited;
	}

	public void setVisited(boolean b) {
		visited = b;
	}
}
