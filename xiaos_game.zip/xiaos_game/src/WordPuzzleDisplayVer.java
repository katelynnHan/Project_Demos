import java.util.ArrayList;

import engine.Actor;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class WordPuzzleDisplayVer extends Actor {
	private int whichBox; // keeps track of which box the player is on
	private ArrayList<LetterBox> letterBoxes;
	private boolean letterTyped;
	private String currentLetter;
	private boolean completedWord; // whether the game has been completed
	private boolean isKeyDown;
	private boolean letterSet;
	private String enteredAnswer; // answer that the user entered
	private String solution;
	private boolean isWon;
	private boolean cantType;

	public WordPuzzleDisplayVer(String solution, boolean won) {
		if (!won) {
			String path = getClass().getClassLoader().getResource("Resource/box.png").toString();
			Image img = new Image(path, 339, 96, true, true);
			setImage(img);
			letterBoxes = new ArrayList<LetterBox>();

			// Keeping track of which box the person is on
			whichBox = -1;
			letterSet = true;
			currentLetter = ""; // the current letter pressed

			initializeBoxes(solution.length()); // initializing boxes

			enteredAnswer = ""; // the answer the person entered

			this.solution = solution;
		} else {
			String path = getClass().getResource("Resource/openBoxNoKey.png").toString();
			setImage(new Image(path, 339, 180, true, true));
		}
	}

	@Override
	public void addedToWorld() {

	}

	@Override
	public void act(long now) {
		House r = (House) getWorld();

		// Keyboard input
		if (r.isViewingInventory()) {
			cantType = true;
		}else if (!isWon && !r.isViewingInventory()) {
			if (letterBoxes != null && whichBox < letterBoxes.size() && !cantType) {
				if (getWorld().isKeyPressed(KeyCode.A)) {
					currentLetter = "A";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.B)) {
					currentLetter = "B";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.C)) {
					currentLetter = "C";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.D)) {
					currentLetter = "D";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.E)) {
					currentLetter = "E";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.F)) {
					currentLetter = "F";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.G)) {
					currentLetter = "G";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.H)) {
					currentLetter = "H";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.I)) {
					currentLetter = "I";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.J)) {
					currentLetter = "J";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.K)) {
					currentLetter = "K";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.L)) {
					currentLetter = "L";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.M)) {
					currentLetter = "M";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.N)) {
					currentLetter = "N";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.O)) {
					currentLetter = "O";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.P)) {
					currentLetter = "P";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.Q)) {
					currentLetter = "Q";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.R)) {
					currentLetter = "R";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.S)) {
					currentLetter = "S";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.T)) {
					currentLetter = "T";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.U)) {
					currentLetter = "U";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.V)) {
					currentLetter = "V";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.W)) {
					currentLetter = "W";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.X)) {
					currentLetter = "X";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.Y)) {
					currentLetter = "Y";
					isKeyDown = true;
					letterSet = false;
				} else if (getWorld().isKeyPressed(KeyCode.Z)) {
					currentLetter = "Z";
					isKeyDown = true;
					letterSet = false;
				} else {
					isKeyDown = false;
				}

				if (!isKeyDown && !letterSet) {
					if (whichBox >= 0) {
						LetterBox current = letterBoxes.get(whichBox);
						current.setLetter(currentLetter);
						enteredAnswer += currentLetter;
					}
					letterSet = true;
					whichBox++;
				}
			} else if (cantType && !r.isViewingInventory() && r.isKeyPressed(KeyCode.C)) {
				cantType = true;
			} else if (cantType && !r.isViewingInventory() && !r.isKeyPressed(KeyCode.C)) {
				cantType = false;
			} else {
				completedWord = true;
				setOnKeyPressed(null);
			}
		}
	}

	public void initializeBoxes(int num) {
		for (int i = 0; i < num; i++) {
			letterBoxes.add(new LetterBox(""));
		}
	}

	public LetterBox getLetterBox(int i) {
		return letterBoxes.get(i);
	}

	public void setLetterBox(int i, LetterBox b) {
		removeBoxes();
		letterBoxes.set(i, b);
		addBoxes();
	}
	
	public void resetLetterBoxes() {
		for(int i = 0; i < letterBoxes.size(); i++) {
			letterBoxes.set(i, new LetterBox(""));
		}
		
		whichBox = -1;
		enteredAnswer = "";
		completedWord = false;
	}

	public void removeBoxes() {
		for (int i = 0; i < letterBoxes.size(); i++) {
			getWorld().getChildren().remove(letterBoxes.get(i));
		}
	}

	public void addBoxes() {
		for (int i = 0; i < letterBoxes.size(); i++) {
			LetterBox cBox = letterBoxes.get(i);

			cBox.setY(this.getY() + 20);
			cBox.setX(this.getX() + cBox.getImage().getWidth() * i + 13 * (i + 1));

			getWorld().getChildren().add(cBox);
		}
	}

	public boolean getCompletedWord() {
		return completedWord;
	}

	public void setCompletedWord(boolean b) {
		completedWord = b;
	}

	// Returns answer the user entered
	public String getEnteredAnswer() {
		return enteredAnswer;
	}
}
