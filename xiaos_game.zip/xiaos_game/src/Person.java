import java.util.ArrayList;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Person extends Item {
	private Item favoriteFood; // favorite food of the person
	private Item giving; // item the person gives to us
	private boolean setGivenText;
	private boolean fed; // if person has been fed
	private boolean given;
	private ArrayList<String> hungryDialogue;
	private int hungryCounter;
	private ArrayList<String> fullDialogue;
	private int fullCounter;
	private ImageView nextButton;

	public Person(String name, Item favorite, Item give) {
		super(name, name + " looks hungry...");

		setText(name + " looks hungry... ", "", "");

		giving = give;
		favoriteFood = favorite;

		hungryDialogue = new ArrayList<String>();
		hungryCounter = 0;

		fullDialogue = new ArrayList<String>();
		fullCounter = 0;

		String next = getClass().getResource("Resource/nextButton.png").toString();
		nextButton = new ImageView(new Image(next, 20, 20, true, true));

		nextButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (!fed) {
					if (hungryCounter < hungryDialogue.size()) {
						if (hungryDialogue.size() - hungryCounter >= 3) {
							if (!hungryDialogue.get(hungryCounter + 1).equals("")
									&& !hungryDialogue.get(hungryCounter + 2).equals("")) {
								setText("\"" + hungryDialogue.get(hungryCounter), hungryDialogue.get(hungryCounter + 1),
										hungryDialogue.get(hungryCounter + 2) + "\"");
							} else if (hungryDialogue.get(hungryCounter + 1).equals("")) {

								setText("\"" + hungryDialogue.get(hungryCounter) + "\"",
										hungryDialogue.get(hungryCounter + 1), hungryDialogue.get(hungryCounter + 2));

							} else if (hungryDialogue.get(hungryCounter + 2).equals("")) {

								setText("\"" + hungryDialogue.get(hungryCounter),
										hungryDialogue.get(hungryCounter + 1) + "\"",
										hungryDialogue.get(hungryCounter + 2));
							}

							hungryCounter += 3;
						} else if (hungryDialogue.size() - hungryCounter == 2) {
							if (!hungryDialogue.get(hungryCounter + 1).equals("")) {

								setText("\"" + hungryDialogue.get(hungryCounter),
										hungryDialogue.get(hungryCounter + 1) + "\"", "");

							} else if (hungryDialogue.get(hungryCounter + 1).equals("")) {

								setText("\"" + hungryDialogue.get(hungryCounter) + "\"",
										hungryDialogue.get(hungryCounter + 1), "");
							}

							hungryCounter += 2;
						} else if (hungryDialogue.size() - hungryCounter == 1) {
							setText("\"" + hungryDialogue.get(hungryCounter) + "\"", "", "");
							hungryCounter += 1;
						}
					}
				} else if (fed) {
					if (fullCounter < fullDialogue.size()) {
						if (fullDialogue.size() - fullCounter >= 3) {
							if (!fullDialogue.get(fullCounter + 1).equals("")
									&& !fullDialogue.get(fullCounter + 2).equals("")) {
								setText("\"" + fullDialogue.get(fullCounter), fullDialogue.get(fullCounter + 1),
										fullDialogue.get(fullCounter + 2) + "\"");
							} else if (fullDialogue.get(fullCounter + 1).equals("")) {

								setText("\"" + fullDialogue.get(fullCounter) + "\"", fullDialogue.get(fullCounter + 1),
										fullDialogue.get(fullCounter + 2));

							} else if (fullDialogue.get(fullCounter + 2).equals("")) {

								setText("\"" + fullDialogue.get(fullCounter), fullDialogue.get(fullCounter + 1) + "\"",
										fullDialogue.get(fullCounter + 2));
							}

							fullCounter += 3;
						} else if (fullDialogue.size() - fullCounter == 2) {
							if (!fullDialogue.get(fullCounter + 1).equals("")) {

								setText("\"" + fullDialogue.get(fullCounter), fullDialogue.get(fullCounter + 1) + "\"",
										"");

							} else if (fullDialogue.get(fullCounter + 1).equals("")) {

								setText("\"" + fullDialogue.get(fullCounter) + "\"", fullDialogue.get(fullCounter + 1),
										"");
							}

							fullCounter += 2;
						} else if (fullDialogue.size() - fullCounter == 1) {
							setText("\"" + fullDialogue.get(fullCounter) + "\"", "", "");
							fullCounter += 1;
						}
					}
				}

				updateViewImage(getViewingPath());
				getViewSprite().setX(getWorld().getPrefWidth() / 2 - getViewSprite().getImage().getWidth() / 2);
				getViewSprite().setY(140 - getViewSprite().getImage().getHeight() / 2);
			}
		});
	}

	public Item getFavoriteFood(Item i) {
		return favoriteFood;
	}

	public Item getGiving() {
		return giving;
	}

	@Override
	public void act(long now) {
		super.act(now);

		if (fed && !setGivenText) {
			setGivenText = true;
			setText(getName() + " seems satisfied after their meal and decides", " to give you a " + giving.getName(),
					"");
		}
	}

	@Override
	public void usedOn(Item i) {
		if (i.getName().equals(favoriteFood.getName()) && !given) {
			updateViewImage(giving.getImage());
			House r = (House) getWorld();
			r.getPlayableCharacter().getInventory().add(giving);
			r.getPlayableCharacter().getInventory().remove(i);
			fed = true;
			given = true;

			getViewSprite().setX(getWorld().getPrefWidth() / 2 - getViewSprite().getImage().getWidth() / 2);
			getViewSprite().setY(150 - getViewSprite().getImage().getWidth() / 2);
		} else if (!i.getName().equals(favoriteFood.getName())) {
			setText(getName() + " is confused with what to do with this,", "maybe try something else?", "");
			getViewSprite().setX(getWorld().getPrefWidth() / 2 - getViewSprite().getImage().getWidth() / 2);
			getViewSprite().setY(140 - getViewSprite().getImage().getHeight() / 2);
		}
	}

	@Override
	public void display() {
		super.display();

		if (!fed) {
			if (hungryDialogue.size() >= 1) {
				nextButton.setX(getWorld().getPrefWidth() - 100);
				nextButton.setY(getWorld().getPrefHeight() - 40);
				getWorld().getChildren().add(nextButton);
			}
		} else if (fed) {
			if (fullDialogue.size() >= 1) {
				nextButton.setX(getWorld().getPrefWidth() - 100);
				nextButton.setY(getWorld().getPrefHeight() - 40);
				getWorld().getChildren().add(nextButton);
			}
		}

		getViewSprite().setX(getWorld().getPrefWidth() / 2 - getViewSprite().getImage().getWidth() / 2);
		getViewSprite().setY(140 - getViewSprite().getImage().getHeight() / 2);
	}

	@Override
	public void removeDisplay() {
		super.removeDisplay();
		if (fed) {
			setText(getName() + " looks delighted and full", "", "");
			updateViewImage(getViewingPath());

			if (fullDialogue.size() >= 1) {
				getWorld().getChildren().remove(nextButton);
			}
		} else if (!fed) {
			setText(getName() + " looks hungry...", "", "");
			if (hungryDialogue.size() >= 1) {
				getWorld().getChildren().remove(nextButton);
			}
		}

		fullCounter = 0;
		hungryCounter = 0;
	}

	public void setFullText(String... fulls) {
		for (String f : fulls) {
			fullDialogue.add(f);
		}
	}

	public void setHungryText(String... hungries) {
		for (String f : hungries) {
			hungryDialogue.add(f);
		}
	}
}
