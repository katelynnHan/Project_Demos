import engine.Actor;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.text.Text;

public class Item extends Actor {
	private House room;

	private String name;
	private String bio;
	private int numUses;
	private Text examineInstructions;
	private boolean examineInstructionsRemoved;
	private boolean examineInstructionsAdded;
	private Text windowInstructions;
	private boolean windowInstructionsRemoved;
	private boolean windowInstructionsAdded;

	private ImageView examineWindow;
	private ImageView textBox;
	private Text line1;
	private Text line2;
	private Text line3;

	private boolean inViewMode;
	// private ViewingSprite viewingSprite;
	private ImageView viewingSprite;
	private String viewingPath;

	private boolean isKey;
	private boolean isTorch;
	private boolean isDoor;
	private boolean examinable;

	public Item() {
		name = "None";
		bio = "Nothing";
		numUses = 0;
		examineInstructions = new Text("Press 'E' to examine");
		examineInstructionsRemoved = true;
		examineInstructionsAdded = false;

		windowInstructions = new Text("Press Backspace to exit");
		windowInstructionsRemoved = true;
		windowInstructionsAdded = false;

		line1 = new Text("Name: " + name);
		line2 = new Text(bio);
		line3 = new Text("");

		inViewMode = false;

		String path = getClass().getResource("Resource/examineScreen.png").toString();
		examineWindow = new ImageView(new Image(path, 360, 240, true, true));
		String pathText = getClass().getResource("Resource/textBox.png").toString();
		textBox = new ImageView(new Image(pathText, 360, 84, true, true));

		viewingPath = getClass().getResource("Resource/blankImage.png").toString();
		viewingSprite = new ImageView(new Image(viewingPath, 0, 0, false, false));
	
		examinable = true;
	}

	public Item(String n, String b) {
		name = n;
		bio = b;
		numUses = 0;
		examineInstructions = new Text("Press 'E' to examine");
		examineInstructionsRemoved = true;
		examineInstructionsAdded = false;
		inViewMode = false;

		windowInstructions = new Text("Press Backspace to exit");
		windowInstructionsRemoved = true;
		windowInstructionsAdded = false;

		line1 = new Text("Name: " + name);
		line2 = new Text(bio);
		line3 = new Text("");

		String path = getClass().getResource("Resource/examineScreen.png").toString();
		examineWindow = new ImageView(new Image(path, 360, 240, true, true));

		String pathText = getClass().getResource("Resource/textBox.png").toString();
		textBox = new ImageView(new Image(pathText, 360, 84, true, true));

		viewingPath = getClass().getResource("Resource/blankImage.png").toString();
		viewingSprite = new ImageView(new Image(viewingPath, 0, 0, false, false));
	
		examinable = true;
	}
	
	public Item(String name, String bio, String pathh, double width, double height) {
		this.name = name;
		this.bio = bio;
		
		examineInstructions = new Text("Press 'E' to examine");
		examineInstructionsRemoved = true;
		examineInstructionsAdded = false;
		inViewMode = false;

		windowInstructions = new Text("Press Backspace to exit");
		windowInstructionsRemoved = true;
		windowInstructionsAdded = false;
		
		line1 = new Text("Name: " + name);
		line2 = new Text(bio);
		line3 = new Text("");
		
		String path = getClass().getResource("Resource/examineScreen.png").toString();
		examineWindow = new ImageView(new Image(path, 360, 240, true, true));

		String pathText = getClass().getResource("Resource/textBox.png").toString();
		textBox = new ImageView(new Image(pathText, 360, 84, true, true));
	
		examinable = true;
		
		viewingPath = pathh;
		setImage(new Image(viewingPath, width, height, true, true));
		viewingSprite = new ImageView(new Image(viewingPath, width * 2, height * 2, true, true));
	}

	public String getName() {
		return name;
	}

	public String getBio() {
		return bio;
	}

	public int getNumUses() {
		return numUses;
	}

	public void setName(String n) {
		name = n;
	}

	public void setBio(String b) {
		bio = b;
	}

	public void setNumUses(int i) {
		numUses = i;
	}

	public boolean inViewMode() {
		return inViewMode;
	}

	public void setInViewMode(boolean b) {
		inViewMode = false;
	}

	public String toString() {
		String tbr = "";
		tbr += getName() + "\n";
		tbr += getBio() + "\n";

		if (numUses > 1000) {
			tbr += "Indefinite Uses.";
		} else {
			tbr += "You can use this " + getNumUses() + " times";
		}

		return tbr;
	}

	@Override
	public void act(long now) {
		House room = (House) getWorld();
		PlayableCharacter c = getOneIntersectingObject(PlayableCharacter.class);

		if (examinable) {
			if (c == null && !examineInstructionsRemoved) {
				getWorld().getChildren().remove(examineInstructions);
				examineInstructionsRemoved = true;
				examineInstructionsAdded = false;
			}

			if (c != null) {
				if (!examineInstructionsAdded && !inViewMode) {
					examineInstructions.setX(getWorld().getPrefHeight() - 30);
					examineInstructions.setY(getWorld().getPrefHeight() - 5);
					getWorld().getChildren().add(examineInstructions);

					examineInstructionsRemoved = false;
					examineInstructionsAdded = true;
				}

				if (getWorld().isKeyPressed(KeyCode.E) && !inViewMode && !room.isViewingInventory()) {
					inViewMode = true;
					room.setIsViewingItem(true);
					examine();

					if (!windowInstructionsAdded) {
						windowInstructions.setX(getWorld().getPrefHeight() - 30);
						windowInstructions.setY(getWorld().getPrefHeight() - 5);
						getWorld().getChildren().add(windowInstructions);
						windowInstructionsAdded = true;
						windowInstructionsRemoved = false;
					}
				}

				if (inViewMode && !examineInstructionsRemoved) {
					getWorld().getChildren().remove(examineInstructions);
					examineInstructionsRemoved = true;
					examineInstructionsAdded = false;
				}
			}

			if (inViewMode) {
				if (getWorld().isKeyPressed(KeyCode.BACK_SPACE) && inViewMode) {
					if (!windowInstructionsRemoved) {
						getWorld().getChildren().remove(windowInstructions);
						windowInstructionsAdded = false;
						windowInstructionsRemoved = true;
					}

					endExamine();
					inViewMode = false;
					room.setIsViewingItem(false);
				}
			}
		}

		if (inViewMode && room.getPlayableCharacter().getInventory().getSelectedItem() != null) {
			usedOn(room.getPlayableCharacter().getInventory().getSelectedItem());
		}
	}

	public void examine() {
		examineWindow.setX(getWorld().getPrefWidth() / 2 - 180);
		examineWindow.setY(20);
		textBox.setX(examineWindow.getX());
		textBox.setY(examineWindow.getY() + 270);

		line1.setX(textBox.getX() + 10);
		line1.setY(textBox.getY() + 20);
		line2.setX(line1.getX());
		line2.setY(line1.getY() + 20);
		line3.setX(line1.getX());
		line3.setY(line2.getY() + 20);

		getWorld().getChildren().addAll(examineWindow, textBox, line1, line2, line3);

		display();
	}

	public void display() { // will be overridden
		viewingSprite.setX(getWorld().getPrefWidth() / 2 - getWidth());
		viewingSprite.setY(140 - getHeight());
		getWorld().getChildren().add(viewingSprite);
	}

	public void setText(String one, String two, String three) {
		line1.setText(one);
		line2.setText(two);
		line3.setText(three);
	}

	public void endExamine() {
		getWorld().getChildren().removeAll(examineWindow, textBox, line1, line2, line3, windowInstructions);
		windowInstructionsAdded = false;
		windowInstructionsRemoved = true;
		inViewMode = false;
		House r = (House) getWorld();
		r.setIsViewingItem(false);

		removeDisplay();
	}

	public void removeDisplay() { // will be overridden
		if (viewingSprite != null) {
			getWorld().getChildren().remove(viewingSprite);
		}
		setText("Name: " + getName(), getBio(), "");
	}

	public String getViewingPath() {
		return viewingPath;
	}

	public void setViewingPath(String p) {
		viewingPath = p;
	}

	public ImageView getViewSprite() {
		return viewingSprite;
	}

	public void updateViewImage(String path, double width, double height) { // width x height
		viewingSprite.setImage(new Image(path, width, height, true, true));
		viewingPath = path;
	}
	
	public void updateViewImage(Image img) {
		viewingSprite.setImage(img);
	}

	public void updateViewImage(String path) { // twice the size of original
		viewingSprite.setImage(new Image(path, getWidth() * 2, getHeight() * 2, true, true));
		viewingPath = path;
	}

	public void setIsKey(boolean b) {
		isKey = b;
	}

	public boolean isKey() {
		return isKey;
	}

	public void setIsTorch(boolean b) {
		isTorch = true;
	}

	public boolean isTorch() {
		return isTorch;
	}
	
	public boolean isDoor() {
		return isDoor;
	}
	
	public void setIsDoor(boolean b) {
		isDoor = b;
	}

	public void removeExamineText() {
		getWorld().getChildren().remove(examineInstructions);
		examineInstructionsAdded = false;
		examineInstructionsRemoved = true;
	}

	public void usedOn(Item i) { // when a character selects an item to use
		setText("You can't use " + i.getName() + " on ", this.getName(), "");
	}

	public boolean examinable() {
		return examinable;
	}

	public void setExaminable(boolean b) {
		examinable = b;
	}
}
