import engine.World;
import javafx.scene.image.Image;

public class Room2Object extends RoomObject {
	private PieceOfPaper paper;
	private Key key;
	private WordPuzzle wordPz1;
	
	public Room2Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}
	
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		key = new Key();
		key.setX(120);
		key.setY(120);
		
		wordPz1 = new WordPuzzle("PROCEED", "Locked Box", "Looks like a word puzzle", key);
		wordPz1.setX(300);
		wordPz1.setY(300);
		
		paper = new PieceOfPaper("You see that box on the ground? ","","",
				"That’s a word puzzle.","","",
				"Here’s a riddle to help you solve it:","","",
				"The frog jumps twice, the frog jumps ",
				"thrice.", "",
				"Hint: it’s a word. The word", 
				"given is PROCEED… good luck.", "", 
				"- x");
		paper.setX(400);
		paper.setY(300);
		
		add(wordPz1);
		add(paper);
	}
}
