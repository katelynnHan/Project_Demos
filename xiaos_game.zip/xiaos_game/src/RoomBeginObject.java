import engine.World;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
//this is the title screen 
public class RoomBeginObject extends RoomObject {
	private ImageView startButton;
	private ImageView controlButton;
	private ImageView backButton;
	private ImageView title;
	private ImageView controlScreen;
	private Text controls;
	private ImageView background;
	
	public RoomBeginObject(World w) {
		super(w);
	}
	
	@Override
	public void addAllObjects() {
		String pathTitle = getClass().getResource("Resource/titleJayEphEx.png").toString();
		title = new ImageView(new Image(pathTitle, 466, 158, true, true));
		title.setX(22);
		title.setY(20);
		
		String pathStart = getClass().getResource("Resource/startButton.png").toString();
		startButton = new ImageView(new Image(pathStart, 110, 80, true, true));
		startButton.setX(200);
		startButton.setY(180);
		
		startButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				House r = (House)getWorld();
				r.nextRoom();
			}
		});
		
		String pathControl = getClass().getResource("Resource/controlButton.png").toString();
		controlButton = new ImageView(new Image(pathControl, 74, 26, true, true));
		controlButton.setX(210);
		controlButton.setY(240);
		
		controlButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String controlScreenPath = getClass().getResource("Resource/examineScreen.png").toString();
				controlScreen = new ImageView(new Image(controlScreenPath, 420, 280, true, true));
				controlScreen.setX(getWorld().getPrefWidth()/2 - 210);
				controlScreen.setY(20);
				
				controls = new Text("Controls: \n"
						+ "- Moving\n"
							+ "\t- Use WASD or Arrow Keys\n"
						+ "- Examining Objects\n"
							+ "\t- Press 'E' to examine objects\n"
							+ "\t- Press backspace to stop examining objects");
				controls.setX(getWorld().getPrefWidth()/2 - 190);
				controls.setY(50);
				
				String pathBack = getClass().getResource("Resource/backButton.png").toString();
				backButton = new ImageView(new Image(pathBack, 50, 50, true, true));
				
				backButton.setX(450);
				backButton.setY(325);
				
				getWorld().getChildren().addAll(controlScreen, backButton, controls);
				
				backButton.setOnMousePressed(new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						remove(controls);
						remove(controlScreen);
						remove(backButton);
					}
				});
			}
		});
		
		String backgroundPath = getClass().getResource("Resource/floor.png").toString();
		background = new ImageView(new Image(backgroundPath, 500, 375, true, true));
		
		add(background);
		add(startButton);
		add(controlButton);
		add(title);
	}
}
