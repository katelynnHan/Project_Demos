import engine.World;
import javafx.scene.image.Image;

public class Room7Object extends RoomObject {
	public Room7Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}
	
	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		GettableItem chicken = new GettableItem("Chicken", "Yum!");
		String chickenPath = getClass().getResource("Resource/chicken.png").toString();
		chicken.setImage(new Image(chickenPath, 50, 50, true, true));
		chicken.updateViewImage(chickenPath);
		
		IceCube ice = new IceCube(chicken);
		ice.setX(320);
		ice.setY(200);
		
		Item sweetMadame = new Item("Sweet Madame", "Crispy and tender (with a touch of sweet!)");
		String madamePath = getClass().getResource("Resource/sweetMadame.png").toString();
		sweetMadame.setImage(new Image(madamePath, 50, 50, true, true));
		sweetMadame.updateViewImage(madamePath);
		
		Item almonds = new Item("Almonds", "Nutritious! But too much is toxic!");
		String almondPath = getClass().getResource("Resource/almond.png").toString();
		almonds.setImage(new Image(almondPath, 50, 50, true, true));
		almonds.updateViewImage(almondPath);
		
		Item bookShelf = new Item("Bookshelf", "A big bookshelf full of books");
		String shelfPath = getClass().getResource("Resource/bookShelf.jpg").toString();
		bookShelf.setImage(new Image(shelfPath, 100, 100, true, true));
		bookShelf.updateViewImage(shelfPath);
		bookShelf.setX(20);
		bookShelf.setY(20);
		
		Person lisa = new Person("Lisa", sweetMadame, almonds);
		String lisaPath = getClass().getResource("Resource/lisa.png").toString();
		lisa.setImage(new Image(lisaPath, 80, 80, true, true));
		lisa.updateViewImage(lisaPath);
		lisa.setX(40);
		lisa.setY(130);
		
		lisa.setHungryText("Hi darling, I'm Lisa, anything,", 
				"I can do for you?");
		lisa.setFullText("Ahah, who knew there was someone", 
		"who would be able to figure out", 
		"my tastes? I’m really happy that", 
		"there’s someone who pays attention", 
		"to me like this.", "",
		"Anyways here’s the almonds that", 
		"you need to make Xiao’s almond",
		"tofu………",
		"...", "","",
		"Oh my I’ve accidentally said his", 
		"name. Oh well…", "",
		"You see, for as long as I remember,",  
		"Xiao has been tied down to this", 
		"place because of a sin he committed.",
		"He escaped from the underlands.", "","",
		"Since then he’s been forced to be a", 
		"sort of Grim Reaper that judges", 
		"those who pass by here.",
		"And not one person has passed the", 
		"test so far.", "",
		"Qiqi and I choose to", 
		"stay with him because we want to", 
		"keep him company,",
		"and also because we know we won’t pass either. ", "", "",
		"After a while, your soul gets", 
		"whittled away and you start", 
		"disintegrating.", 
		"To be honest I don't now how long",
		"I have left.", "",
		"And don’t listen to what Xiao says.", 
		"This test is not just a test of", 
		"your soul’s purity, but also his", 
		"The green goo in those pots", 
		"are a remnant of his soul so", 
		"technically this dish requires", 
		"the cooperation of both you AND", 
		"him.", "",
		"Perhaps","","",
		"you will be the one to finally", 
		"create the perfect almond tofu.",
		"So that Xiao can finally be freed from", 
		"his burden.");
		
		Key key = new Key();
		
		WordPuzzle pz = new WordPuzzle("LIBRARY", "Locked Box", 
				"This isn't too repetitive, is it?", key);
		pz.setX(400);
		pz.setY(270);
		
		Torch torch = new Torch();
		torch.setX(450);
		torch.setY(150);
		
		//Cooking pot recipes
		Item sugarPile = new Item("Sugar Pile", "A pile of sugar");
		Item leaf = new Item("Leaf", "Some greenery would look nice here");
		
		Item sweetFlower = new Item("Sweet Flower", "A pretty flower, and sweet too!");
		String flowerPath = getClass().getResource("Resource/sweetFlower.png").toString();
		sweetFlower.setImage(new Image(flowerPath, 50, 50, true, true));
		sweetFlower.updateViewImage(flowerPath);
				
		Recipe sweetFlowerRec = new Recipe(sweetFlower, sugarPile, leaf);

		Recipe sweetMadameRec = new Recipe(sweetMadame, sweetFlower, chicken);
		
		Item iron = new Item("Iron", "");
		Item hammer = new Item("Hammer", "");
		Recipe keyRec = new Recipe(key, iron, hammer);
		
		Item almondTofu = new Item("Almond Tofu", "Xiao's favorite food");
		String tofuPath = getClass().getResource("Resource/almondTofu.png").toString();
		almondTofu.setImage(new Image(tofuPath, 50, 50, true, true));
		almondTofu.updateViewImage(tofuPath);
		
		Item milk = new Item("Milk", "Gives you strong bones!");
		
		Item sugar = new Item("Sugar", "");
		
		Recipe almondTofuRec = new Recipe(almondTofu, almonds, milk, sugar);
		
		CookingPot pot = new CookingPot(almondTofuRec, keyRec, sweetMadameRec, sweetFlowerRec);
		pot.setX(120);
		pot.setY(180);
		
		PieceOfPaper paper = new PieceOfPaper("In this room you will find an", 
				"interesting librarian named Lisa who hails from", 
				"Mondstadt.", 
				"For the box, my hint is... where Lisa works", "","",
				"- x");
		paper.setX(130);
		paper.setY(50);
		
		Book lore = new Book("Introduction To The Two Different Worlds", "Looks like a textbook...?",
				"Death is just a passing part of our", 
				"cycle of existance.", "",
				"The most important part of one's existance", 
				"comes after death", "",
				"One's separation into either the underlands", 
				"or upperlands can determine one's quality of",
				"existance.",
				"Obide by our laws of existance and you will", 
				"make it into the upperlands and achieve", 
				"eternal happiness.", 
				"Defy us however...", "", "", 
				"...and you will face the repercussions.");
		lore.setX(120);
		lore.setY(110);
		
		Book openBook = new Book("Journal", "A shiny and very important journal",
				"6/1/22 (Happy Pride Month!)", "", "",
				"- Worked from 1 to late night",
				"- Worked at home",
				"- Didn't really create any new features,", 
				"just added items into rooms in different", 
				"combinations to create a game",
				"- Spent a big part of the day just", 
				"brainstorming how my game was going to", 
				"flow and I wrote up a simple story",
				"- Planning to create different \"useless\"",
				"(this is one of them heheheheh) items that", 
				"are just there for display to make the", 
				"game look pretty");
		
		Book recipe = new Book("Recipe for Sweet Madame", "A cook book",
				"Region: Mondstadt", "","",
				"Materials:",
				"- Sweet Flower", 
				"- Chicken",
				"The sweet syrup covers the crispy",
				"tender chicken");
		recipe.setX(160);
		recipe.setY(80);
		
		String deskPath = getClass().getResource("Resource/table.png").toString();
		Item desk = new Item("Desk", "Looks like someone was working here", deskPath, 100, 100);
		desk.setX(480 - desk.getImage().getWidth());
		desk.setY(30);
		
		String openPath = getClass().getResource("Resource/openBook.png").toString();
		openBook.setImage(new Image(openPath, 30, 30, true, true));
		openBook.updateViewImage(openPath);
		openBook.setX(490 - desk.getImage().getWidth());
		openBook.setY(40);
		
		String bluePath = getClass().getResource("Resource/blueCarpet.png").toString();
		Item blueCarp = new Item("", "", bluePath, 120, 120);
		blueCarp.setExaminable(false);
		blueCarp.setX(480 - blueCarp.getImage().getWidth());
		blueCarp.setY(20);
		
		String greenPath = getClass().getResource("Resource/greenCarpet.png").toString();
		Item greenCarp = new Item("","", greenPath, 230, 230);
		greenCarp.setExaminable(false);
		greenCarp.setX(20);
		greenCarp.setY(20);
		
		String largeFlowerPath = getClass().getResource("Resource/largeFlower.png").toString();
		Item pottedFlower = new Item("Large Potted Flower", "Still smells fresh!", largeFlowerPath, 60, 60);
		pottedFlower.setX(20);
		pottedFlower.setY(355 - pottedFlower.getImage().getHeight());
		
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
		
		//Decor
		add(blueCarp);
		add(greenCarp);
		add(desk);
		add(openBook);
		add(bookShelf);
		add(lore);
		add(pottedFlower);
		
		//functionality stuff
		add(pot);
		add(pz);
		add(torch);
		add(ice);
		add(paper);
		add(recipe);
		add(lisa);
	}
}
