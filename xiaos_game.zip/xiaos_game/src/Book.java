import java.util.ArrayList;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Book extends Item {
	private ArrayList<String> lines;
	private int numLines;
	private int counter;
	private ImageView nextButton;

	public Book(String title, String desc, String... ls) {
		super(title, desc);

		lines = new ArrayList<String>();

		for (String s : ls) {
			lines.add(s);
		}

		String path = getClass().getResource("Resource/book.png").toString();
		setImage(new Image(path, 40, 40, true, true));

		updateViewImage(path);

		numLines = lines.size();

		String next = getClass().getResource("Resource/nextButton.png").toString();
		nextButton = new ImageView(new Image(next, 20, 20, true, true));
		nextButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (counter < lines.size()) {
					if (lines.size() - counter >= 3) {
						if (!lines.get(counter + 1).equals("") && !lines.get(counter + 2).equals("")) {
							setText("\"" + lines.get(counter), lines.get(counter + 1), lines.get(counter + 2) + "\"");
						} else if (lines.get(counter + 1).equals("")) {
							
							setText("\"" + lines.get(counter) + "\"", lines.get(counter + 1),
									lines.get(counter + 2));
							
						} else if (lines.get(counter + 2).equals("")) {
							
							setText("\"" + lines.get(counter), lines.get(counter + 1) + "\"",
									lines.get(counter + 2));
						}

						counter += 3;
					} else if (lines.size() - counter == 2) {
						if (!lines.get(counter + 1).equals("")) {
							
							setText("\"" + lines.get(counter), lines.get(counter + 1) + "\"", "");
							
						}else if(lines.get(counter + 1).equals("")) {
							
							setText("\"" + lines.get(counter) + "\"", lines.get(counter + 1), "");
						}
						
						counter += 2;
					} else if (lines.size() - counter == 1) {
						setText("\"" + lines.get(counter) + "\"", "", "");
						counter += 1;
					}
				}
			}
		});

		setText(getName(), getBio(), "");
		counter = 0;
	}

	@Override
	public void removeDisplay() {
		super.removeDisplay();
		setText(getName(), getBio(), "");
		if (numLines >= 1) {
			getWorld().getChildren().remove(nextButton);
			counter = 0;
			setText(getName(), getBio(), "");
		}
	}

	@Override
	public void display() {
		super.display();
		if (numLines >= 1) {
			nextButton.setX(getWorld().getPrefWidth() - 100);
			nextButton.setY(getWorld().getPrefHeight() - 40);
			getWorld().getChildren().add(nextButton);
		}
	}
}
