import javafx.scene.image.Image;

public class Door extends Item {
	private boolean isLocked;
	private boolean viewUnlocked;
	private boolean isNextRoom;
	private boolean examinable;

	public Door() {
		super("Locked Door", "A huge wooden door stands infront of you");

		setIsDoor(true);
		isLocked = true;
		updateImage();
		examinable = true;
		isNextRoom = false;
	}

	public void updateImage() {
		if (isLocked) {
			String pathClosed = getClass().getResource("Resource/doorClosed.png").toString();
			setImage(new Image(pathClosed, 58, 64, true, true));
			if (!viewUnlocked) {
				updateViewImage(pathClosed);
			}else {
				String pathOpen = getClass().getResource("Resource/doorOpened.png").toString();
				updateViewImage(pathOpen);
			}
		} else {
			String path = getClass().getResource("Resource/doorOpened.png").toString();
			setImage(new Image(path, 58, 64, true, true));
			updateViewImage(path);
		}
	}
	
	public void setIsLocked(boolean b) {
		isLocked = b;
	}

	public boolean getIsLocked() {
		return isLocked;
	}

	@Override
	public void act(long now) {
		if(isLocked) {
			examinable = true;
		}else {
			examinable = false;
		}
		
		if (examinable) {
			super.act(now);
		}

		House r = (House) getWorld();

		if (viewUnlocked && !r.isViewingItem()) {
			examinable = false;
			isLocked = false;
		}

		updateImage();
	}

	public void usedOn(Item i) { // when character selects an item to use
		if (i.isKey()) {
			House r = (House) getWorld();
			r.getPlayableCharacter().getInventory().remove(i);
			viewUnlocked = true;

			String path = getClass().getResource("Resource/doorOpened.png").toString();
			setViewingPath(path);
			if (getViewSprite() != null) {
				updateViewImage(path);
			}
			setText("Name: Opened Door", "The door opens with a click, looks like", "you can pass now");
		} else if (!i.isKey()) {
			super.usedOn(i);
		}
	}
	
	public boolean isNextRoom() {
		return isNextRoom;
	}
	
	public void setIsNextRoom(boolean b) {
		isNextRoom = b;
	}
}
