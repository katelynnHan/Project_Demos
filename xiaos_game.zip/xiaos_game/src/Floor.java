import engine.Actor;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Floor extends Actor {
	private Image img;
	
	public Floor() {
		String path = getClass().getResource("Resource/floor.png").toString();
		img = new Image(path, 500, 500, true, true);
		setImage(img);
	}

	@Override
	public void act(long now) {

	}
}
