import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class LetterBox extends ImageView {
	private String path;
	private double width;
	private double height;
	private String letter;

	public LetterBox(String l) {
		width = 33;
		height = 60;
		
		if(l.equals("")) {
			path = getClass().getResource("Resource/letterBox.png").toString();
			setImage(new Image(path, width, height, true, true));
		}else {
			path = getClass().getResource("Resource/" + l + ".png").toString();
			setImage(new Image(path, width, height, true, true));
		}
	}
	
	public String getLetter() {
		return letter;
	}
	
	public void setLetter(String l) {
		letter = l;
		updateLetter();
	}
	
	public void updateLetter() {
		if(letter.equals("")) {
			path = getClass().getResource("Resource/letterBox.png").toString();
			setImage(new Image(path, width, height, true, true));
		}else {
			path = getClass().getResource("Resource/" + letter + ".png").toString();
			setImage(new Image(path, width, height, true, true));
		}
	}
}
