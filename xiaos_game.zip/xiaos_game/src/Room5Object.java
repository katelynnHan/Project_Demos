import engine.World;
import javafx.scene.image.Image;

public class Room5Object extends RoomObject {
	public Room5Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/pinkCheckers.jpg").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 650, 500, true, true));
	}
	
	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		Item seaweed = new Item("Seaweed", "Slimy, but delicious");
		String seaPath = getClass().getResource("Resource/seaweed.png").toString();
		seaweed.setImage(new Image(seaPath, 50, 50, true, true));
		seaweed.updateViewImage(seaPath);
		
		WordPuzzle pz = new WordPuzzle("SEAWEED","Locked Box", "...another one?", seaweed);
		pz.setX(130);
		pz.setY(300);
		
		GettableItem fish = new GettableItem("Fish", "So that's where the smell was coming from!");
		String fishPath = getClass().getResource("Resource/fish.png").toString();
		fish.setImage(new Image(fishPath, 40, 40, true, true));
		fish.updateViewImage(fishPath);
		fish.setX(300);
		fish.setY(20);
		
		Item rice = new Item("Rice", "Perfect with practically anything!");
		
		Item riceBalls = new Item("Rice Balls", "Perfect when you're on the go!");
		String riceBallPath = getClass().getResource("Resource/riceBall.png").toString();
		riceBalls.setImage(new Image(riceBallPath, 50, 50, true, true));
		riceBalls.updateViewImage(riceBallPath);
		
		Recipe riceBallRec = new Recipe(riceBalls, rice, seaweed, fish);
		
		CookingPot pot = new CookingPot(riceBallRec);
		pot.setX(400);
		pot.setY(30);
		
		
		Key key = new Key();
		
		Person qiqi = new Person("Qiqi", riceBalls, key);
		String qiqiPath = getClass().getResource("Resource/qiqi.png").toString();
		qiqi.setImage(new Image(qiqiPath, 60, 60, true, true));
		qiqi.updateViewImage(qiqiPath);
		qiqi.setX(430);
		qiqi.setY(280);
		qiqi.setHungryText("Qiqi wants coco-milk...");
		qiqi.setFullText("Not coco-milk... but still good,", 
				"Qiqi is satisfied.", "", 
				"Qiqi hopes, this key can help you", "", "",
				"Qiqi hopes, that you won't end up like the rest", "", "",
				"...", "","",
				"Please help him");
		
		PieceOfPaper paper = new PieceOfPaper("Welcome to the kitchen.","","",
				"You see that petite girl in the", 
				"corner? That's Qiqi, she has the key", 
				"but she refuses to give it to anyone", 
				"unless she gets some coco-milk.","","",
				"Of course coco-milk is hard to", 
				"obtain in this realm.","",
				"But luckily she settles for rice",
				"balls.", "",
				"There should be enough", 
				"materials to make some.", "",
				"- x", "", "",
				"P.S. For the box, think about what", 
				"ingredient you're missing.");
		paper.setX(150);
		paper.setY(100);
		
		Book recipe = new Book("Recipe for Rice Balls", "A cook book",
				"Region: Liyue", "","",
				"Materials:", 
				"- Rice", 
				"- Seaweed", 
				"- Fish (for filling)", "","",
				"A convenient and yummy snack perfect", 
				"for when you're on the go!");
		recipe.setX(100);
		recipe.setY(100);
		
		Torch torch = new Torch();
		torch.setX(400);
		torch.setY(150);
		
		String tablePath = getClass().getResource("Resource/simpleTable.png").toString();
		Item table = new Item("Table", "A simple table", tablePath, 70, 70);
		table.setX(300);
		table.setY(20);
		table.setExaminable(false);
		
		String checkPath = getClass().getResource("Resource/pinkCheckers.jpg").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(checkPath, 650, 500, true, true));
		
		String baskPath = getClass().getResource("Resource/fruitBasket.png").toString();
		Item fruitBasket = new Item("Fruit Basket", "It's all fruits, probably can't use these for rice balls", baskPath, 40, 40);
		fruitBasket.setX(330);
		fruitBasket.setY(30);
		
		String plantPath = getClass().getResource("Resource/smallTwoleafPlant.png").toString();
		Item plant = new Item("Small Potted Plant", "It's nice to see so much greenery around here!", plantPath, 40, 40);
		plant.setX(30);
		plant.setY(10);
		
		String bluePath = getClass().getResource("Resource/blueCarpet.png").toString();
		Item carp = new Item("", "", bluePath, 60, 60);
		carp.setExaminable(false);
		carp.setX(20);
		carp.setY(20);
		
		//Decor
		add(table);
		add(fruitBasket);
		add(carp);
		add(plant);
		
		add(paper);
		add(recipe);
		add(qiqi);
		add(pot);
		add(pz);
		add(fish);
		add(torch);
	}
}
