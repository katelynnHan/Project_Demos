import engine.Actor;
import javafx.scene.image.Image;
import javafx.scene.text.Text;

public class DisappearingText extends Actor {
	private int time; //time it stays for (seconds
	private String message;
	private Text txt;
	private long oldTime;
	private long newTime;
	
	public DisappearingText(String str, int time) {
		this.time = time;
		String path = getClass().getResource("Resource/blankImage.png").toString();
		setImage(new Image(path, 1, 1, true, true));
		
		txt = new Text(str);
	}
	
	@Override
	public void addedToWorld() {
		this.setX(-10);
		this.setY(-10);
		
		txt.setX(10);
		txt.setY(20);
		
		getWorld().getChildren().add(txt);
	}

	@Override
	public void act(long now) {
		if(newTime == 0) {
			oldTime = now;
			newTime = now;
		}
		
		newTime = now;
		
		
		
		if(newTime - oldTime >= Math.pow(10, 9) * time) {
			getWorld().getChildren().remove(txt);
			getWorld().getChildren().remove(this);
		}
	}
}
