import engine.World;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
//the ending screen
public class RoomEndObject extends RoomObject {
	
	public RoomEndObject(World w) {
		super(w);
	}
	
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
//		String bgPath = getClass().getResource("Resource/floor.png").toString();
//		background = new ImageView(new Image(bgPath, 500, 375, true, true));
		
		String winPath = getClass().getResource("Resource/youWin.png").toString();
		ImageView youWin = new ImageView(new Image(winPath, 463, 180, true, true));
		youWin.setX(18);
		youWin.setY(30);
		
		String xiaoPath = getClass().getResource("Resource/xiaoCat.png").toString();
		ImageView xiaoCat = new ImageView(new Image(xiaoPath, 200, 200, true, true));
		xiaoCat.setX(getWorld().getPrefWidth()/2 - xiaoCat.getImage().getWidth()/2);
		xiaoCat.setY(120);
		
		Text txt = new Text("Stay tuned in for our (nonexistant) upcoming sequel where we save");
		Text txt2 = new Text("Xiao from the underlands!");
		Text note = new Text("Dear Mr. Ferrante, I am not a story writer, so there are plot holes :(");
		txt.setX(20);
		txt2.setX(20);
		note.setX(20);
		
		txt2.setY(355);
		txt.setY(340);
		note.setY(370);
		
		add(youWin);
		add(xiaoCat);
		add(txt);
		add(txt2);
		add(note);
	}

	public void removeAllObjects() {
		
	}
}
