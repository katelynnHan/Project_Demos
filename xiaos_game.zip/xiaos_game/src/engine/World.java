package engine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javafx.animation.AnimationTimer;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public abstract class World extends javafx.scene.layout.Pane {
	private javafx.animation.AnimationTimer timer;
	boolean isTimerRunning;
	HashSet<KeyCode> keysDown;
	boolean isWidthSet;
	boolean isHeightSet;
	boolean isDimensionsSet;

	public World() {
		timer = new AnimationTimer() {

			@Override
			public void handle(long now) {
				act(now); // world is acting

				Iterator<Actor> iter = getObjects(Actor.class).iterator();
				while (iter.hasNext()) {
					Actor a = iter.next();
					if (a != null && a.getWorld() != null) {
						a.act(now);
					}

				}

			}

		};

		keysDown = new HashSet<KeyCode>();
		isDimensionsSet = false;
		isHeightSet = false;
		isWidthSet = false;
		isTimerRunning = false;

		// Listener for width property
		widthProperty().addListener(new ChangeListener<Number>() {

			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				if (oldValue.doubleValue() == 0 && newValue.doubleValue() > 0) {
					isWidthSet = true;

					if (isWidthSet && isHeightSet && !isDimensionsSet) {
						isDimensionsSet = true;
						onDimensionsInitialized();
					}
				}
			}

		});

		sceneProperty().addListener(new ChangeListener<Scene>() {
			@Override
			public void changed(ObservableValue<? extends Scene> observable, Scene oldValue, Scene newValue) {
				if (oldValue == null && newValue != null) {
					requestFocus();
				}
			}
		});

		// Listener to height property
		heightProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				if (oldValue.doubleValue() == 0 && newValue.doubleValue() > 0) {
					isHeightSet = true;

					if (isWidthSet && isHeightSet && !isDimensionsSet) {
						isDimensionsSet = true;
						onDimensionsInitialized();
					}
				}
			}
		});

		setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				keysDown.add(event.getCode());
			}
		});

		setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				keysDown.remove(event.getCode());
			}
		});
	}

	public abstract void act(long now);

	public void remove(Actor actor) {
		this.getChildren().remove(actor);
	}

	public void add(Actor actor) {
		this.getChildren().add(actor);
		actor.addedToWorld();
	}

	public void addAll(Actor... a) {
		for (int i = 0; i < a.length; i++) {
			this.getChildren().add(a[i]);
			a[i].addedToWorld();
		}
	}

	public void start() {
		isTimerRunning = true;
		timer.start();
	}

	public void stop() {
		isTimerRunning = false;
		timer.stop();
	}

	public <A extends Actor> java.util.List<A> getObjects(java.lang.Class<A> cls) {

		List<A> ret = new ArrayList<A>();
		int l = getChildren().size();
		for (int i = 0; i < l; i++) {
			if (cls.isInstance(getChildren().get(i))) {
				ret.add((A) getChildren().get(i));
			}
		}
		return (List<A>) ret;

	}

	public <A extends Actor> java.util.List<A> getObjectsAt(double x, double y, java.lang.Class<A> cls) {
		List<A> ret = new ArrayList<A>();

		int l = getChildren().size();
		for (int i = 0; i < l; i++) {
			if (cls.isInstance(getChildren().get(i))) {
				A current = (A) getChildren().get(i);

				double xDis = Math.abs(current.getX() - x);
				double yDis = Math.abs(current.getY() - y);

				double maxXDis = current.getWidth() / 2;
				double maxYDis = current.getHeight() / 2;

				if (xDis <= maxXDis && yDis <= maxYDis) {
					ret.add(current);
				}
			}
		}

		return (List<A>) ret;
	}
	
	public <A extends Actor> A getObjectOfTypeClass(java.lang.Class<A> cls) {
		for(int i = 0; i < getChildren().size(); i++) {
			if(getChildren().get(i).getClass().isInstance(cls)) {
				return (A) getChildren().get(i);
			}
		}
		return null;
	}

	public void addKeysDown(KeyCode... k) {
		for (int i = 0; i < k.length; i++) {
			keysDown.add(k[i]);
		}
	}

	public boolean isKeyPressed(KeyCode k) {
		for (int i = 0; i < keysDown.size(); i++) {
			if (keysDown.contains(k)) {
				return true;
			}
		}
		return false;
	}

	public boolean isStopped() {
		return !isTimerRunning;
	}

	public void removeKey(KeyCode k) {
		keysDown.remove(k);
	}

	public abstract void onDimensionsInitialized();
}