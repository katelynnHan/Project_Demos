package engine;

import java.util.ArrayList;

public abstract class Actor extends javafx.scene.image.ImageView {
	boolean addedToWorld = false;

	public Actor() {

	}

	public abstract void act(long now);

	public double getHeight() {
		return this.getImage().getHeight();
	}

	public double getWidth() {
		return this.getImage().getWidth();
	}

	public void addedToWorld() {

	}

	public World getWorld() {
		return (World) this.getParent();
	}

	public void move(double dx, double dy) {
		this.setX(this.getX() + dx);
		this.setY(this.getY() + dy);
	}

	
	public <A extends Actor> java.util.List<A> getIntersectingObjects(java.lang.Class<A> cls) {

		ArrayList<A> list = new ArrayList<A>();
		World parent = (World) getParent();

		for (int i = 0; i < parent.getObjects(cls).size(); i++) {
			if (!parent.getObjects(cls).get(i).equals(this)
					&& isIntersecting(parent.getObjects(cls).get(i))

			) {
				list.add(parent.getObjects(cls).get(i));
			}
		}

		return list;

	}

	
	public <A extends Actor> A getOneIntersectingObject(java.lang.Class<A> cls) {

		World parent = (World) getParent();

		for (int i = 0; i < parent.getObjects(cls).size(); i++) {
			if (!parent.getObjects(cls).get(i).equals(this)
					&& isIntersecting(parent.getObjects(cls).get(i))
			) {
				return parent.getObjects(cls).get(i);
			}
		}

		return null;
	}

	public boolean isIntersecting(Actor actor) {
		
		//method in javafx does this 
		
		//checks if boundaries of a node are touching another node
		
		//node.getBounds() (returns boundary), check if that intersects another boundary 
		
		
		return this.getBoundsInParent().intersects(actor.getBoundsInParent());
		
		
		/*
		double thisWidth = this.getImage().getWidth();
		double thisHeight = this.getImage().getHeight();
		double thatWidth = actor.getImage().getWidth();
		double thatHeight = actor.getImage().getHeight();

		double thisX = this.getX();
		double thisY = this.getY();
		double thatX = actor.getX();
		double thatY = actor.getY();

		double distanceX = Math.abs(thisX - thatX);
		double distanceY = Math.abs(thisY - thatY);

		double maxXDis = thisWidth;
		double maxYDis = thisHeight;

		if (thisX >= thatX) {
			maxXDis = thatWidth;
		}

		if (thisY >= thatY) {
			maxYDis = thatHeight;
		}

		return distanceX <= maxXDis && distanceY <= maxYDis;
		*/
	}
	
	public void turnTowards(Actor a) {
		double otherX = a.getX();
		
		if(otherX < this.getX()) {
			this.setScaleX(-1);
		}else if (otherX > this.getX()) {
			this.setScaleX(1);
		}
		
	}
}
