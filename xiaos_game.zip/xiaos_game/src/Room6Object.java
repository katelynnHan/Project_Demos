import engine.World;
import javafx.scene.image.Image;

public class Room6Object extends RoomObject {
	public Room6Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/cobbleStone.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 1300, 500, true, true));
	}
	
	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		Torch torch = new Torch();
		torch.setX(400);
		torch.setY(150);
		
		PieceOfPaper forgeHint = new PieceOfPaper("Welcome to the forging room", "", "",
				"Why don't you try cooking",
				"something else? In this realm you", 
				"can do a lot of things... think,", 
				"how would you make a key?", "","",
				"- x", "", "", 
				"P.S. I know there's an anvil but", 
				"it's covered in moss and unusable.", "",
				"(and mostly because the developer was lazy)");
		
		IceCube ice = new IceCube(forgeHint);
		ice.setX(50);
		ice.setY(100);
		
		Item iron = new Item("Iron", "It's rock hard- well harder than rock");
		
		GettableItem hammer = new GettableItem("Hammer", "Used to forge metal objects");
		String hammerPath = getClass().getResource("Resource/hammer.png").toString();
		hammer.setImage(new Image(hammerPath, 50, 50, true, true));
		hammer.updateViewImage(hammerPath);
		hammer.setX(50);
		hammer.setY(240);
		
		Key key = new Key();
		Recipe keyRec = new Recipe(key, iron, hammer);
		
		CookingPot pot = new CookingPot(keyRec);
		pot.setX(400);
		pot.setY(300);
		
		Bone bone = new Bone("...why is there a bone here?");
		bone.setX(420);
		bone.setY(30);
		
		String anvilPath = getClass().getResource("Resource/anvil.png").toString();
		Item anvil = new Item("Anvil", "You can't use this for forging since Developer is tired :D", anvilPath, 70, 70);
		anvil.setX(20);
		anvil.setY(310);
		
		String swordPath = getClass().getResource("Resource/sword.png").toString();
		Item freedomSworn = new Item("Freedom Sworn", "What a pretty sword!", swordPath, 50, 50);
		freedomSworn.setX(90);
		freedomSworn.setY(290);
		
		String blueCarpet = getClass().getResource("Resource/simpleBlueCarpet.png").toString();
		Item blueCarp = new Item("", "", blueCarpet, 100, 100);
		blueCarp.setExaminable(false);
		blueCarp.setX(20);
		blueCarp.setY(355 - blueCarp.getImage().getHeight());
		
		//Decor
		add(bone);
		House r = (House)getWorld();
		String cobblePath = getClass().getResource("Resource/cobbleStone.png").toString();
		r.getFloor().setImage(new Image(cobblePath, 1300, 500, true, true));
		add(blueCarp);
		add(anvil);
		add(freedomSworn);
		
		add(pot);
		add(hammer);
		add(ice);
		add(torch);
	}
}
