import javafx.scene.image.Image;

public class Bone extends Item {
	public Bone(String bio) {
		super("Bone", bio);
		
		String bonePath = getClass().getResource("Resource/bone.png").toString();
		setImage(new Image(bonePath, 50, 50, true, true));
		updateViewImage(bonePath);
	}
}
