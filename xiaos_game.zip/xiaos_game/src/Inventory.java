import java.util.ArrayList;

import engine.World;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Inventory {
	private ArrayList<ImageView> invens;
	private Item whichItem;
	private boolean canAdd;
	private ImageView invenBox;
	private World world;

	public Inventory(World w) {
		world = w;

		invens = new ArrayList<ImageView>();

		String boxPath = getClass().getResource("Resource/inventory.png").toString();
		invenBox = new ImageView(new Image(boxPath, 464, 128, true, true));
		
		canAdd = true;
	}

	public ArrayList<ImageView> getInventory() {
		return invens;
	}

	public void add(Item item) {
		if (invens.size() < 5) {
			invens.add(item.getViewSprite());
			
			//item.getViewSprite().setOnMousePressed(null);

			item.getViewSprite().setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					House r = (House) world;

					if (r.isViewingInventory() && r.isViewingItem()) {
						whichItem = item;
					}
				}
			});
		}else {
			DisappearingText txt = new DisappearingText("Your inventory is full!", 3);
			world.add(txt);
		}
	}

	public void remove(Item item) {
		invens.remove(item.getViewSprite());

		world.getChildren().remove(item.getViewSprite());
	}

	public ImageView get(int i) {
		return invens.get(i);
	}

	public ImageView getNext() {
		return invens.get(0);
	}

	public void show() { // when the character presses I
		whichItem = null;
		invenBox.setX(world.getPrefWidth() / 2 - 232);
		invenBox.setY(110);
		world.getChildren().add(invenBox);

		House r = (House) world;

		r.setIsViewingInventory(true);

		for (int i = 0; i < invens.size(); i++) {
			ImageView c = invens.get(i);

			c.setX(invenBox.getX() + (56 - c.getImage().getWidth() / 2) + (88 * i));
			c.setY(174 - c.getImage().getHeight() / 2);

			world.getChildren().add(c);
		}
	}

	public void close() {
		whichItem = null;
		world.getChildren().remove(invenBox);

		House r = (House) world;

		r.setIsViewingInventory(false);

		for (int i = 0; i < invens.size(); i++) {
			world.getChildren().remove(invens.get(i));
		}
	}

	public void clear() {
		invens.clear();
	}

	public Item getSelectedItem() {
		return whichItem;
	}

	public void setSelectedItem(Item i) {
		whichItem = i;
	}
}
