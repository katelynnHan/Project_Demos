import java.util.ArrayList;

import javafx.scene.image.Image;

public class CookingPot extends Item { // items can be added to this pot
	private Recipe currentRecipe;
	private ArrayList<Recipe> recipes;
	private int whichRecipe;
	private boolean done; // when you're done making a recipe
	private boolean canSetEmpty; // when you're done and you can set the img to empty
	private boolean nothingAdded;

	public CookingPot(Recipe... r) {
		super("Cooking Pot", "A pot with green bubbles... will this really");
		setText("Cooking Pot", "A pot with green bubbles... will this really", "be okay to cook with?");
		
		String cookPath = getClass().getResource("Resource/cookingPot.png").toString();
		setImage(new Image(cookPath, 50, 50, true, true));
		updateViewImage(cookPath);

		recipes = new ArrayList<Recipe>();

		for (Recipe i : r) {
			recipes.add(i);
		}

		done = false;

		nothingAdded = true;
		this.setInViewMode(false);

		currentRecipe = recipes.get(0);
	}

	@Override
	public void act(long now) {
		super.act(now);

		if (canSetEmpty) {
			setText("Name: Cooking Pot", "Looks like the green goo has runeth dry", "");

			String emptyPath = getClass().getResource("Resource/emptyCookingPot.png").toString();
			updateViewImage(emptyPath);

			setImage(new Image(emptyPath, 50, 50, true, true));

			canSetEmpty = false;
		}
	}

	public Recipe getDish(int i) {
		return recipes.get(i);
	}

	@Override
	public void usedOn(Item i) {

		House r = (House) getWorld();
		if (nothingAdded) {
			nothingAdded = false;

			for (int j = 0; j < recipes.size(); j++) {
				if (recipes.get(j).contains(i.getName())) {
					whichRecipe = j;
					currentRecipe = recipes.get(j);
					break;
				}
			}
		}

		if (currentRecipe.contains(i.getName())) {
			r.getPlayableCharacter().getInventory().remove(i);
			setText("You've added a " + i.getName() + " to the pot...",
					"It starts to bubble more, hey is this really a ", "good idea?");
			currentRecipe.remove(i.getName());

			r.getPlayableCharacter().getInventory().setSelectedItem(null);

			if (currentRecipe.size() == 0) {
				setText("You've obtained a " + recipes.get(whichRecipe).getResult().getName(),
						"Wow you're really good at cooking!", "");
				updateViewImage(recipes.get(whichRecipe).getResult().getViewSprite().getImage());

				getViewSprite().setX(getWorld().getPrefWidth()/2 - getViewSprite().getImage().getWidth()/2);
				getViewSprite().setY(150 - getViewSprite().getImage().getHeight()/2);
				
				r.getPlayableCharacter().getInventory().add(recipes.get(whichRecipe).getResult());

				done = true;
			}
		} else if (!currentRecipe.contains(i.getName())) {
			if (currentRecipe.size() > 0) {
				setText("Are you sure you're supposed to add that? Try", "checking the recipe again!", "");
			} else {
				setText("Looks like this pot is unusable now, since the", "green goo is gone", "");
				done = true;
			}
		}
	}

	@Override
	public void removeDisplay() {
		super.removeDisplay();

		if (done) {
			canSetEmpty = true;
			done = false;
		}
	}
}
