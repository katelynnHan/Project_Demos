import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class WordPuzzle extends Item {

	private String solution;
	private boolean isSolved;
	private boolean isDisplaySolved;
	private Item item;
	private WordPuzzleDisplayVer display;

	private boolean itemGot;
	private boolean itemSetClick;

	private String name;
	private String riddle;

	private String openBoxTxt1;
	private String openBoxTxt2;
	private String openBoxTxt3;

	public WordPuzzle(String originalWord, String name, String bio, Item i) {
		this(originalWord, i);
		
		this.name = name;
		this.riddle = bio;
		
		setName(name);
		setBio(riddle);
		setText(name, riddle, "");

		openBoxTxt1 = "The box opens with a click, there's an item inside";
		openBoxTxt2 = "";
		openBoxTxt3 = "";
	}

	public WordPuzzle(String tbC, Item ii) {
		String path = getClass().getResource("Resource/box.png").toString();
		Image img = new Image(path, 50, 50, true, true);
		setImage(img);

		item = ii;

		solution = "";
		for (int i = 0; i < tbC.length(); i++) {
			if (i % 2 == 0) {
				solution += tbC.charAt(i);
			}
		}

		for (int i = 0; i < tbC.length(); i++) {
			if (i % 3 == 0) {
				solution += tbC.charAt(i);
			}
		}

		isSolved = false;
		display = new WordPuzzleDisplayVer(solution, isSolved);
	}

	public void setItem(Item i) {
		item = i;
	}

	public Item getItem() {
		return item;
	}

	public void setOpenBoxText(String t, String tt, String ttt) {
		openBoxTxt1 = t;
		openBoxTxt2 = tt;
		openBoxTxt3 = ttt;
	}

	public void end() {
		House r = (House) getWorld();
		if (!isSolved()) {
			display.removeBoxes();
			display.resetLetterBoxes();
		} else if (!itemGot) {
			r.getCurrentRoom().remove(item.getViewSprite());
		}
		r.getCurrentRoom().remove(display);
	}

	public boolean isSolved() {
		return isSolved;
	}

	@Override
	public void display() {
		House r = (House) getWorld();
		
		r.setIsViewingItem(true);

		r.getCurrentRoom().add(display);

		display.setX((getWorld().getPrefWidth() - display.getWidth()) / 2);

		if (!isSolved) {
			setText(name, riddle, "");
			display.setY(100);
			display.addBoxes();
		} else if (!itemGot && isSolved) {
			item.getViewSprite().setX(getWorld().getPrefWidth() / 2 - item.getViewSprite().getImage().getWidth());
			item.getViewSprite().setY(165 - item.getImage().getHeight() / 2);
			r.getCurrentRoom().add(item.getViewSprite());
			display.setY(50);
		} else if (itemGot && isSolved) {
			String path = getClass().getResource("Resource/openBoxNoKey.png").toString();
			display.setImage(new Image(path, 339, 180, true, true));
			display.setY(50);
			setText("The box is now empty", "", "");
		}
	}

	@Override
	public void removeDisplay() {
		House r = (House)getWorld();
		r.setIsViewingItem(false);
		end();
	}

	@Override
	public void act(long now) {
		super.act(now);

		House r = (House) getWorld();

		if (!itemSetClick && item.getViewSprite() != null) {
			item.getViewSprite().setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					item.getViewSprite().setOnMousePressed(null);

					House r = (House) getWorld();
					r.getPlayableCharacter().addToInventory(item);
					r.getCurrentRoom().remove(item.getViewSprite());

					itemGot = true;
				}
			});
			itemSetClick = true;
		}

		if (display != null) {
			if (display.getCompletedWord()) {
				if (!isSolved && display.getEnteredAnswer().equals(solution)) {
					String path = getClass().getResource("Resource/openBoxNoKey.png").toString();
					display.setY(50);
					display.setImage(new Image(path, 339, 180, true, true));
					display.removeBoxes();

					item.getViewSprite().setX(getWorld().getPrefWidth() / 2 - item.getViewSprite().getImage().getWidth() / 2);
					item.getViewSprite().setY(165 - item.getImage().getHeight() / 2);
					r.getCurrentRoom().add(item.getViewSprite());
					// display box and item
					setText(openBoxTxt1, openBoxTxt2, openBoxTxt3);
					setName("Open Box");
					isSolved = true;

					String pathNoKey = getClass().getResource("Resource/openBoxNoKey.png").toString();
					this.setImage(new Image(pathNoKey, 50, 100, true, true));
				} else if (!isSolved) {
					setText("You try opening the lid but it doesn't budge", "", "");
				}
			}
		}
	}
}
