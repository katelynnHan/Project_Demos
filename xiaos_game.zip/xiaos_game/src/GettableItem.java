import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class GettableItem extends Item {
	private boolean gottem;
	private boolean setMouseClicked;
	private boolean removedEverything;

	public GettableItem(String n, String b) {
		super(n, b);

	}

	@Override
	public void act(long now) {
		super.act(now);
		
		House r = (House)getWorld();

		if (!setMouseClicked) {
			setOnMousePressed(new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					if (!r.isViewingInventory() && !r.isViewingItem()) {
						gottem = true;
					}
				}
			});
			setMouseClicked = true;
		}

		if (gottem && !removedEverything) {
			DisappearingText notice = new DisappearingText("Obtained " + getName(), 3);
			r.getCurrentRoom().add(notice);
			
			this.removeExamineText();

			r.getPlayableCharacter().getInventory().add(this);

			r.getCurrentRoom().remove(this);

			removedEverything = true;
		}
	}
}
