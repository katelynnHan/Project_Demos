import java.util.ArrayList;

import engine.Actor;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.text.Text;

public class PlayableCharacter extends Actor {
	// Images
	private Image forwardSkele;
	private Image forwardSkeleLeft;
	private Image forwardSkeleRight;
	private Image forwardSkeleBetween;

	private Image backSkele;
	private Image backSkeleLeft;
	private Image backSkeleRight;
	private Image backSkeleBetween;

	private Image rightSkele;
	private Image rightSkeleInner;
	private Image rightSkeleOuter;
	private Image rightSkeleBetween;

	private Image leftSkele;
	private Image leftSkeleInner;
	private Image leftSkeleOuter;
	private Image leftSkeleBetween;

	private int dx;
	private int dy;

	private int walkingPhase; // 0 for idle, 1 for first leg, 2 for between, 3 for next leg, 4 for between
	private long oldTime;
	private long newTime;
	// again
	private boolean movingUp;
	private boolean movingDown;
	private boolean movingLeft;
	private boolean movingRight;
	private boolean moving;

	private boolean facingUp;
	private boolean facingDown;
	private boolean facingRight;
	private boolean facingLeft;

	private Inventory inv;
	private boolean isViewingInventory;

	private boolean canChangeRooms;

	public PlayableCharacter() {
		walkingPhase = 0;
		String forwardPath = getClass().getClassLoader().getResource("Resource/forwardSkele.png").toString();
		String forwardLeftPath = getClass().getClassLoader().getResource("Resource/forwardSkeleLeft.png").toString();
		String forwardRightPath = getClass().getClassLoader().getResource("Resource/forwardSkeleRight.png").toString();
		String forwardBetweenPath = getClass().getClassLoader().getResource("Resource/forwardSkeleBetween.png")
				.toString();

		String backPath = getClass().getClassLoader().getResource("Resource/backSkele.png").toString();
		String backLeftPath = getClass().getClassLoader().getResource("Resource/backSkeleLeft.png").toString();
		String backRightPath = getClass().getClassLoader().getResource("Resource/backSkeleRight.png").toString();
		String backBetweenPath = getClass().getClassLoader().getResource("Resource/backSkeleBetween.png").toString();

		String rightPath = getClass().getClassLoader().getResource("Resource/rightSkele.png").toString();
		String rightInnerPath = getClass().getClassLoader().getResource("Resource/rightSkeleInner.png").toString();
		String rightOuterPath = getClass().getClassLoader().getResource("Resource/rightSkeleOuter.png").toString();
		String rightBetweenPath = getClass().getClassLoader().getResource("Resource/rightSkeleBetween.png").toString();

		String leftPath = getClass().getClassLoader().getResource("Resource/leftSkele.png").toString();
		String leftInnerPath = getClass().getClassLoader().getResource("Resource/leftSkeleInner.png").toString();
		String leftOuterPath = getClass().getClassLoader().getResource("Resource/leftSkeleOuter.png").toString();
		String leftBetweenPath = getClass().getClassLoader().getResource("Resource/leftSkeleBetween.png").toString();

		forwardSkele = new Image(forwardPath, 30, 48, true, true);
		forwardSkeleLeft = new Image(forwardLeftPath, 30, 48, true, true);
		forwardSkeleRight = new Image(forwardRightPath, 30, 48, true, true);
		forwardSkeleBetween = new Image(forwardBetweenPath, 30, 48, true, true);

		backSkele = new Image(backPath, 30, 48, true, true);
		backSkeleLeft = new Image(backLeftPath, 30, 48, true, true);
		backSkeleRight = new Image(backRightPath, 30, 48, true, true);
		backSkeleBetween = new Image(backBetweenPath, 30, 48, true, true);

		rightSkele = new Image(rightPath, 30, 48, true, true);
		rightSkeleInner = new Image(rightInnerPath, 30, 48, true, true);
		rightSkeleOuter = new Image(rightOuterPath, 30, 48, true, true);
		rightSkeleBetween = new Image(rightBetweenPath, 30, 48, true, true);

		leftSkele = new Image(leftPath, 30, 48, true, true);
		leftSkeleInner = new Image(leftInnerPath, 30, 48, true, true);
		leftSkeleOuter = new Image(leftOuterPath, 30, 48, true, true);
		leftSkeleBetween = new Image(leftBetweenPath, 30, 48, true, true);

		this.setImage(forwardSkele);
		dx = 2;
		dy = 2;

		canChangeRooms = true;
	}

	public void addedToWorld() {
		if (inv == null) {
			inv = new Inventory(this.getWorld());
		}
	}

	@Override
	public void act(long now) {
		House r = (House) (getWorld());
		newTime = now;
		movingLeft = false;
		movingRight = false;
		movingUp = false;
		movingDown = false;

		ArrayList<Wall> walls = (ArrayList<Wall>) getIntersectingObjects(Wall.class);

		// Intended motion

		if (!r.isViewingItem() && !isViewingInventory) {
			if (getWorld().isKeyPressed(KeyCode.A) || getWorld().isKeyPressed(KeyCode.LEFT)) {
				movingLeft = true;
				moving = true;

				facingLeft = true;
				facingRight = false;
				facingUp = false;
				facingDown = false;
			}

			if (getWorld().isKeyPressed(KeyCode.D) || getWorld().isKeyPressed(KeyCode.RIGHT)) {
				movingRight = true;
				moving = true;

				facingLeft = false;
				facingRight = true;
				facingUp = false;
				facingDown = false;
			}

			if (getWorld().isKeyPressed(KeyCode.W) || getWorld().isKeyPressed(KeyCode.UP)) {
				movingUp = true;
				moving = true;

				facingLeft = false;
				facingRight = false;
				facingUp = true;
				facingDown = false;
			}

			if (getWorld().isKeyPressed(KeyCode.S) || getWorld().isKeyPressed(KeyCode.DOWN)) {
				movingDown = true;
				moving = true;

				facingLeft = false;
				facingRight = false;
				facingUp = false;
				facingDown = true;
			}

			if (movingRight) {
				facingLeft = false;
				facingRight = true;
				facingUp = false;
				facingDown = false;
			} else if (movingLeft) {
				facingLeft = true;
				facingRight = false;
				facingUp = false;
				facingDown = false;
			} else if (!movingUp && !movingDown) {
				moving = false;
			}

			if (newTime - oldTime >= 200000000) {
				oldTime = newTime;
				newTime = now;
				if (walkingPhase < 4 && moving) {
					walkingPhase++;
				} else if (walkingPhase == 4 && moving) {
					walkingPhase = 1;
				}
			}

			if (!moving) {
				walkingPhase = 0;
			}

			// handling wall collisions
			if (walls.size() == 0) {
				if (movingLeft) {
					move(-dx, 0);
				}

				if (movingRight) {
					move(dx, 0);
				}

				if (movingUp) {
					move(0, -dy);
				}

				if (movingDown) {
					move(0, dy);
				}
			} else if (walls.size() == 1) {
				Wall wall = walls.get(0);
				if (movingLeft) {
					if (!wall.isLeft()) {
						move(-dx, 0);
					}
				}

				if (movingRight) {
					if (!wall.isRight()) {
						move(dx, 0);
					}
				}

				if (movingUp) {
					if (!wall.isTop()) {
						move(0, -dy);
					}
				}

				if (movingDown) {
					if (!wall.isBottom()) {
						move(0, dy);
					}
				}
			} else if (walls.size() == 2) {
				Wall wall1 = walls.get(0);
				Wall wall2 = walls.get(1);

				boolean right = false;
				boolean left = false;
				boolean top = false;
				boolean bottom = false;

				if (wall1.isRight() || wall2.isRight()) {
					right = true;
				}

				if (wall1.isLeft() || wall2.isLeft()) {
					left = true;
				}

				if (wall1.isTop() || wall2.isTop()) {
					top = true;
				}

				if (wall1.isBottom() || wall2.isBottom()) {
					bottom = true;
				}

				if (!movingRight) {
					if (!right) {
						move(dx, 0);
					}
				}

				if (!movingLeft) {
					if (!left) {
						move(-dx, 0);
					}
				}

				if (!movingUp) {
					if (!top) {
						move(0, -dy);
					}
				}

				if (!movingDown) {
					if (!bottom) {
						move(0, dy);
					}
				}
			}

			// Walking animations
			if (facingLeft) {
				if (walkingPhase == 0) {
					setImage(leftSkele);
				} else if (walkingPhase == 1) {
					setImage(leftSkeleInner);
				} else if (walkingPhase == 2) {
					setImage(leftSkeleBetween);
				} else if (walkingPhase == 3) {
					setImage(leftSkeleOuter);
				} else if (walkingPhase == 4) {
					setImage(leftSkeleBetween);
				}
			} else if (facingRight) {
				if (walkingPhase == 0) {
					setImage(rightSkele);
				} else if (walkingPhase == 1) {
					setImage(rightSkeleInner);
				} else if (walkingPhase == 2) {
					setImage(rightSkeleBetween);
				} else if (walkingPhase == 3) {
					setImage(rightSkeleOuter);
				} else if (walkingPhase == 4) {
					setImage(rightSkeleBetween);
				}
			} else if (facingUp) {
				if (walkingPhase == 0) {
					setImage(backSkele);
				} else if (walkingPhase == 1) {
					setImage(backSkeleLeft);
				} else if (walkingPhase == 2) {
					setImage(backSkeleBetween);
				} else if (walkingPhase == 3) {
					setImage(backSkeleRight);
				} else if (walkingPhase == 4) {
					setImage(backSkeleBetween);
				}
			} else if (facingDown) {
				if (walkingPhase == 0) {
					setImage(forwardSkele);
				} else if (walkingPhase == 1) {
					setImage(forwardSkeleLeft);
				} else if (walkingPhase == 2) {
					setImage(forwardSkeleBetween);
				} else if (walkingPhase == 3) {
					setImage(forwardSkeleRight);
				} else if (walkingPhase == 4) {
					setImage(forwardSkeleBetween);
				}
			}
		}

		if (getWorld().isKeyPressed(KeyCode.TAB) && !isViewingInventory) {
			isViewingInventory = true;
			inv.show();
		} else if (getWorld().isKeyPressed(KeyCode.C) && isViewingInventory) {
			isViewingInventory = false;
			inv.close();
		}

		Door d = getOneIntersectingObject(Door.class);

		if (d != null && !d.getIsLocked() && getWorld().isKeyPressed(KeyCode.ENTER) && canChangeRooms
				&& !isViewingInventory) {
			if (d.isNextRoom()) {
				r.nextRoom();
			} else if (!d.isNextRoom()) {
				r.previousRoom();
			}

			canChangeRooms = false;
		} else if (!getWorld().isKeyPressed(KeyCode.ENTER)) {
			canChangeRooms = true;
		}
	}

	public void addToInventory(Item item) {
		inv.add(item);
	}

	public Inventory getInventory() {
		return inv;
	}
}
