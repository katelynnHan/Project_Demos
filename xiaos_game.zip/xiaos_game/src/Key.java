import javafx.scene.image.Image;

public class Key extends GettableItem {
	public Key() {
		super("Key", "It's a silver key!");
		
		setIsKey(true);
		
		String path = getClass().getResource("Resource/key.png").toString();
		setImage(new Image(path, 30, 30, true, true));
		updateViewImage(path);
	}
}
