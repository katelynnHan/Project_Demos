import engine.World;
import javafx.scene.image.Image;

public class Room3Object extends RoomObject {
	public Room3Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}

	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		GettableItem rice = new GettableItem("Rice", "Perfect with practically anything!");
		String ricePath = getClass().getResource("Resource/rice.png").toString();
		rice.setImage(new Image(ricePath, 50, 50, true, true));
		rice.updateViewImage(ricePath);
		
		IceCube ice = new IceCube(rice);
		ice.setX(50);
		ice.setY(50);
		
		Item key = new Key();
		
		WordPuzzle pz = new WordPuzzle("GLACIER", "Locked Box", "Another one of these...", key);
		pz.setX(300);
		pz.setY(240);
		
		PieceOfPaper paper = new PieceOfPaper("Don’t worry about the ice cube for now", "","",
				"(no this is not a programming error", 
				"we'll get back to it)","",
				"Just repeat what you did in the last ", 
				"room.", "",
				"The word is related to a cold thing,", 
				"you can find it in the arctic.","",
				"- x");
		paper.setX(420);
		paper.setY(200);
		
		add(ice);
		add(paper);
		add(pz);
	}
}
