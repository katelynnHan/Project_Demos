import engine.World;
import javafx.scene.image.Image;

public class Room4Object extends RoomObject {
	public Room4Object(World w) {
		super(w);
	}
	
	@Override public void addAllObjectsVisitedVer() {
		super.addAllObjectsVisitedVer();
		String path = getClass().getResource("Resource/floor.png").toString();
		House r = (House)getWorld();
		r.getFloor().setImage(new Image(path, 500, 375, true, true));
	}
	
	@Override
	public void addAllObjectsNonVisitedVer() {
		super.addAllObjectsNonVisitedVer();
		
		House h = (House)getWorld();
		DisappearingText txt = new DisappearingText("Room " + h.getRoomNumber(), 3);
		getWorld().add(txt);
		
		Torch torch = new Torch();
		torch.setX(350);
		torch.setY(50);
		
		Key key = new Key();
		key.setX(150);
		key.setY(325);
		
		GettableItem iron = new GettableItem("Iron", "It's rock hard- well harder than rock");
		String ironPath = getClass().getResource("Resource/iron.png").toString();
		iron.setImage(new Image(ironPath, 50, 50, true, true));
		iron.updateViewImage(ironPath);
		iron.setX(50);
		iron.setY(200);
		
		PieceOfPaper paper = new PieceOfPaper("Remember that block of ice in the", 
				"last room? There's a torch here,", 
				"try connecting the lines.", 
				"- x");
		paper.setX(430);
		paper.setY(70);
		
		Item carpet = new Item("Carpet", "A very stylish carpet");
		String cPath = getClass().getResource("Resource/blueCarpet.png").toString();
		carpet.setImage(new Image(cPath, 150, 150, true, true));
		carpet.updateViewImage(cPath);
		carpet.setX(20);
		carpet.setY(20);
		
		Item couch = new Item("Couch", "Looks like a comfortable place to nap");
		String couchPath = getClass().getResource("Resource/couch.png").toString();
		couch.setImage(new Image(couchPath, 100, 100, true, true));
		couch.updateViewImage(couchPath);
		couch.setX(45);
		couch.setY(20);
		
		Item pinkPlant = new Item("Succulent", "Look at it it's adorable!");
		String pinkPath = getClass().getResource("Resource/pinkPotSucculent.png").toString();
		pinkPlant.setImage(new Image(pinkPath, 30, 30, true, true));
		pinkPlant.updateViewImage(pinkPath);
		pinkPlant.setX(150);
		pinkPlant.setY(20);
		
		Item yellowPlant = new Item("Succulent", "It's so cute and it's even got a twin!");
		String yellowPath = getClass().getResource("Resource/yellowPotSucculent.png").toString();
		yellowPlant.setImage(new Image(yellowPath, 30, 30, true, true));
		yellowPlant.updateViewImage(yellowPath);
		yellowPlant.setX(20);
		yellowPlant.setY(20);
		
		Item brownCarpet = new Item("Brown Carpet", "");
		brownCarpet.setExaminable(false);
		String brownPath = getClass().getResource("Resource/brownCarpet.png").toString();
		brownCarpet.setImage(new Image(brownPath, 70, 70, true, true));
		brownCarpet.updateViewImage(brownPath);
		brownCarpet.setX(getWorld().getPrefWidth() - 20 - brownCarpet.getImage().getWidth());
		brownCarpet.setY(getWorld().getPrefHeight() - 20 - brownCarpet.getImage().getHeight());
		
		Item chica = new Item("Cute Plushie", "I wonder who it belonged to before?");
		String chicaPath = getClass().getResource("Resource/chica.png").toString();
		chica.setImage(new Image(chicaPath, 40, 40, true, true));
		chica.updateViewImage(chicaPath);
		chica.setX(430);
		chica.setY(300);
		
		//decor
		add(carpet);
		add(couch);
		add(yellowPlant);
		add(pinkPlant);
		add(brownCarpet);
		add(chica);
		
		//functions
		add(iron);
		add(torch);
		add(key);
		add(paper);
	}
}
