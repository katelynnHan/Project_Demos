import javafx.scene.image.ImageView;

public class PuddleOfWater extends ImageView {

}
