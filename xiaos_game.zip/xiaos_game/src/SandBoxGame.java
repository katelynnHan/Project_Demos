import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SandBoxGame extends Application {
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		BorderPane b = new BorderPane();
		
		House r = new House();
		b.setCenter(r);
		
		Scene s = new Scene(b);

		r.start();
		stage.setScene(s);
		
		stage.show();
	}

}
