import java.util.ArrayList;

import engine.World;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class House extends World {
	private boolean isViewingItem;
	private boolean isViewingInventory;

	private boolean isLastRoom;
	private Wall leftWall;
	private Wall rightWall;
	private Wall topWall;
	private Wall bottomWall;
	
	private ImageView restartButton;

	private ArrayList<RoomObject> roomObjs;
	private int roomNumber;
	private RoomObject currentRoom;

	// Stuff inside the room
	private Floor f;
	private PlayableCharacter p;

	public House() {
		this.setPrefHeight(375);
		this.setPrefWidth(500);

		initializeRooms();

		roomNumber = 0;
		currentRoom = roomObjs.get(0);
		
		String path = getClass().getResource("Resource/restartButton.png").toString();
		restartButton = new ImageView(new Image(path, 25, 25, true, true));
		restartButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				restart();
			}
		});

		currentRoom.addAllObjects();
	}

	@Override
	public void act(long now) {
		
	}

	@Override
	public void onDimensionsInitialized() {

	}

	public void initializeRooms() {
		roomObjs = new ArrayList<>();
		roomObjs.add(new RoomBeginObject(this));
		roomObjs.add(new Room1Object(this));
		roomObjs.add(new Room2Object(this));
		roomObjs.add(new Room3Object(this));
		roomObjs.add(new Room4Object(this));
		roomObjs.add(new Room5Object(this));
		roomObjs.add(new Room6Object(this));
		roomObjs.add(new Room7Object(this));
		roomObjs.add(new Room8Object(this));
		roomObjs.add(new Room9Object(this));
		roomObjs.add(new Room10Object(this));
		roomObjs.add(new RoomEndObject(this));
	}

	public boolean isViewingItem() {
		return isViewingItem;
	}

	public void setIsViewingItem(boolean i) {
		isViewingItem = i;
	}
	
	public boolean isViewingInventory() {
		return isViewingInventory;
	}
	
	public void setIsViewingInventory(boolean b) {
		isViewingInventory = b;
	}

	public boolean getIsLastRoom() {
		return isLastRoom;
	}

	public void setIsLastRoom(boolean b) {
		isLastRoom = b;
	}

	public void addAllObjects() {
		if(getRoomNumber() <= 10) {
		f = new Floor();

		p = new PlayableCharacter();
		p.setX(getPrefWidth() / 2 - p.getWidth() / 2);
		p.setY(getPrefHeight() - p.getHeight() - 30);

		leftWall = new Wall(true);
		rightWall = new Wall(true);
		topWall = new Wall(false);
		bottomWall = new Wall(false);

		topWall.setX(0);
		bottomWall.setX(0);
		rightWall.setX(getPrefWidth() - rightWall.getImage().getWidth());
		bottomWall.setY(getPrefHeight() - bottomWall.getImage().getHeight());

		leftWall.setIsLeft(true);
		rightWall.setIsRight(true);
		topWall.setIsTop(true);
		bottomWall.setIsBottom(true);
		
		restartButton.setX(getPrefWidth() - 25);
		
		if(getRoomNumber() < 10) {
			this.add(p);
		}
		this.add(f);
		this.add(topWall);
		this.add(leftWall);
		this.add(bottomWall);
		this.add(rightWall);
		}
	}
	
	public void removeAllObjects() {
		this.remove(topWall);
		this.remove(leftWall);
		this.remove(bottomWall);
		this.remove(rightWall);
		this.remove(p);
		this.remove(f);
		this.getChildren().remove(restartButton);
	}
	
	public void restart() {
		currentRoom.removeAllObjects();
		this.removeAllObjects();
		roomNumber = 0;
		
		this.setIsViewingInventory(false);
		this.setIsViewingItem(false);
		
		currentRoom = roomObjs.get(roomNumber);
		currentRoom.addAllObjects();
		roomObjs.clear();
		initializeRooms();
	}

	public void resetPlayerBottom() { //When the player enters a room
		p.setX(this.getPrefWidth() / 2 - p.getWidth() / 2);
		p.setY(this.getPrefHeight() - p.getHeight() - 20);
		
		putPlayerOntop();
	}
	
	public void resetPlayerTop() { //when player returns to a room
		p.setX(this.getPrefWidth() / 2 - p.getWidth() / 2);
		p.setY(30);
		
		putPlayerOntop();
	}
	
	public void putPlayerOntop() {
		if(getRoomNumber() >= 1 && getRoomNumber() <= 10) {
			remove(getPlayableCharacter());
			add(getPlayableCharacter());
		}
	}

	public Door getEntrance() {
		return currentRoom.getEntrance();
	}
	
	public Door getExit() {
		return currentRoom.getExit();
	}
	
	public Floor getFloor() {
		return f;
	}
	
	public Wall getLeftWall() {
		return leftWall;
	}
	
	public Wall getRightWall() {
		return rightWall;
	}
	
	public Wall getBottomWall() {
		return bottomWall;
	}
	
	public Wall getTopWall() {
		return topWall;
	}
	
	public PlayableCharacter getPlayableCharacter() {
		return p;
	}
	
	public RoomObject getCurrentRoom() {
		return currentRoom;
	}
	
	public int getRoomNumber() {
		return roomNumber;
	}
	
	public void nextRoom() { //moves to the next room
		currentRoom.removeAllObjects();
		roomNumber++;
		
		if(roomNumber == 1) {
			addAllObjects();
			this.getChildren().add(restartButton);
		}

		currentRoom = roomObjs.get(roomNumber);

		currentRoom.addAllObjects();
		resetPlayerBottom();
		getCurrentRoom().setVisited(true);
	}
	
	public void previousRoom() { //moves to the previous room
		currentRoom.removeAllObjects();
		roomNumber--;

		currentRoom = roomObjs.get(roomNumber);

		currentRoom.addAllObjects();
		resetPlayerTop();
	}
}
