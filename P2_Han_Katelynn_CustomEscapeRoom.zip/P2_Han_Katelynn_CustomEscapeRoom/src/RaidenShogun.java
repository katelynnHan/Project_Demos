
public class RaidenShogun extends Person {
	/**boolean for if you can leave the room or not*/
	private boolean distracted;
	
	/** The amount of times you can interact with her before she attacks*/
	private int provokeTimes;
	
	public RaidenShogun() {
		super("raiden_shogun", 
				"A tall woman with dark braided hair. Her menancing glare is directed straight at you. \n"
				+ "In her right hand she wields a katana... better not provoke her");
		distracted = false;
	}

	@Override
	public void speak() {
		if(!distracted) {
			System.out.println("The Shogun stares dead into your eyes but doesn't respond "
					+ "to anything that you're saying");
		}else {
			System.out.println("The Shogun muches on the red bean paste dangos and doesn't "
					+ "pay you any mind");
		}
	}
	
	public boolean isDistracted() {
		return distracted;
	}

	/**
	 * Sets the distracted state of the Raiden Shogun
	 * */
	public void setDistraction(boolean distracted) {
		this.distracted = distracted;
	}
}
