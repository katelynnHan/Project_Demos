
public interface CommandHandler {
	public boolean execute(String command );
	
	public void printHelp();
}
