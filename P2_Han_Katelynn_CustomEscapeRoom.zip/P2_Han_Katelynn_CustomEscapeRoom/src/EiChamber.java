public class EiChamber extends Room{
	/** max number of turns the player can take before failing */
	private int maxTurns;
	
	/** the number of turns the player has taken */
	private int numTurns;
	
	/** the door of Shogun's Chamber */
	private Container shogunsDoor;
	
	private RaidenShogun ei;
	
	public EiChamber(String description, String intro, int maxTurns) {
		super(description, intro);
		this.maxTurns = maxTurns;
		
		//Add a blank element and random piece of food
		
		Element elem = new Element("none");
		elem.setVisibility(false);
		add(elem);
		
		Food f = new Food("invisible_food", "You shouldn't ever see this", false);
		f.setVisibility(false);
		add(f);
		
		shogunsDoor = new Container("shoguns_door", 
				"A Japanese styled sliding door with a large circular symbol on it", false, true);
		add(shogunsDoor);
		
		Container travelersBag = new Container("travelers_bag", 
				"A wore leather bag that's been through many adventures");
		travelersBag.add(new TextItem("travelers_diary", "A small, weathered, leather bound book", 
				"You flip through your diary: \n\n3/15/XXXX \nI've finally arrived in Inazuma after so long!\n" + 
		"Hopefully I can find my brother here… And to do that, I must ask the Raiden Shogun if " + 
		"she knows anything! \n\n3/17/XXXX \nThe Shogun is such a scary lady! She’s got these scary purple\n" + 
		"eyes that she glares everyone down with… I don’t know if she’ll answer my questions… But it's so \n"
		+ "weird... she's apparently obssessed with sweet things, like deserts, how can such a scary lady like "
		+ "sweets so much? All she ever talks about is deserts! \n\n3/21/XXXX \n" + 
		"I’m in big trouble, I caused some ruckus in Inazuma city and now I have an arrest warrant on me! \n" + 
		"Now all the guards are coming after me and I can’t even walk around the city without being \n" + 
		"recognized!! Even the Shogun is personally coming after me. This is not how this trip was supposed " + 
		"to be T-T\n"));
		travelersBag.add(new TextItem("travelers_manuel", 
		"A hard cover book with a picture of a 7 seven symbols on the front",
		"I’ve been in this world for over 2 years and I’m finally able to use all the elements! \n"
		+ "\tI’ve decided to write these down in case I ever forget which is which\n"
		+ "\tPyro - Fire\n"
		+ "\tCryo - Ice\n"
		+ "\tHydro - Water\n"
		+ "\tElectro - Electricity\n\n"
		+ "Reactions: combining different elements can have different results!\n"
		+ "\tMelt - Cryo and Pyro, pyro melts the cryo\n"
		+ "\tVaporize - Hydro and Pyro, creates steam\n"
		+ "\tOverload - Pyro and Electro, causes a big explosion!\n"
		+ "\tSuperconduct - Electro and Cryo, creates a cloud of ice that dissapates\n"
		+ "\tFreeze - Cryo and Hydro, it freezes things!"));
		add(travelersBag);
		
		Container eisChest = new PasswordLockedContainer("shoguns_chest", 
				"An ornate chest decorated with brass pieces. I wonder what the password could be? "
				+ "\nProbably something that the Shogun really likes.", "desert");
		eisChest.add(new TextItem("shoguns_diary", "A purple, tattered, leather bound diary. It appears \n"
				+ "To belong to the Shogun. It seems like it hasn't been touched in a while", 
		"A big chunk of the diary is ripped out, but you read what you can salvage: \n"
		+ "\nI've always been a fan of Tomoki's cakes and deserts, but recently I've really been craving\n"
		+ "something chewy and sweet, like maybe mochi!"));
		add(eisChest);

		ei = new RaidenShogun();
		
		add(ei);
		
		add(new WoodenHammer());
		
		add(new IceCube());
		
		add(new RedBeanPasteMochiRecipe());
	}
	
	public void printRoomPrompt() {
		System.out.println(
				"You have taken " + numTurns + " turns. You have " + (maxTurns - numTurns) + 
				" turns left to escape.");
	}
	
	public void onCommandAttempted(String command, boolean handled) {
		if (handled) {
			numTurns++;
		}
	}
	
	public boolean escaped() {
		if(ei.isDistracted()) {
			shogunsDoor.unlock();
			System.out.println("You hear a click and realize that the door behind the Shogun has unlocked!");
		}
		
		if(shogunsDoor.isOpen()) {
			return true;
		}
		
		return false;
	}
	
	public boolean failed() {
		if(numTurns >= maxTurns) {
			return true;
		}
		
		return false;
	}
	
	public void onEscaped() {
		System.out.println("You watch as the Shogun munches fervously on the mochi you made.\n"
				+ "You nervously opened the door and stepped out of the chamber. "
				+ "After successfully distracting the Shogun, you've \nescaped her chamber! "
				+ "(Looks like the Shogun REALLY likes her deserts)");
		System.out.println("You escaped in " + numTurns + " turns!");
	}
	
	public void onFailed() {
		System.out.println("Electricity crackles in the air, you turn around to see the Raiden" + 
				"Shogun lifting her katana above her head, \npreparing for a strike. You hear a strike of thunder before your"
				+ "vision goes black. You failed to escape in " + maxTurns + " turns");
	}
}
