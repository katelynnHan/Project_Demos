import java.util.Scanner;

public class Food extends Item implements Edible, CommandHandler {
	/**
	 * Determines if you need it for the story to progress
	 */
	private boolean canEat;

	public Food(String name, String description, boolean canEat) {
		super(name, description);
		this.canEat = canEat;
	}

	@Override
	public void eat() {
		if (canEat) {
			System.out.println("Nutritious!");
			this.getRoom().remove(this);
		} else {
			System.out.println("You can't eat the " + getName() + "! What if you need it later?");
		}
	}

	@Override
	public void use() {
		eat();
	}

	@Override
	public void useOn(Item item) {
		System.out.println();
	}

	@Override
	public boolean execute(String command) {
		Scanner scan = new Scanner(command);

		if (scan.hasNext()) {
			String com = scan.next();
			if (com.equals("eat")) {
				if (scan.hasNext()) {
					String itemName = scan.next();

					if (itemName.equals(getName())) {
						eat();

						return true;
					}
				} else {
					System.out.println("Eat what?");

					return true;
				}
			}
		}

		return false;
	}

	@Override
	public void printHelp() {
		if (isVisible()) {
			System.out.println("You can try to eat the " + getName());
		}
	}
}
