public class EiChamberDriver {
	public static void main(String[] args) {
		String intro = "You wake up in a daze in a large Japanese styled room, you can’t seem to remember anything. \n"
				+ "You scan the room and find that it’s decorated to look like a Shogun’s room. The room is dimly lit \n"
				+ "with lanterns emitting a purple glow. You hoist yourself to your feet from the tatami mats and look \n"
				+ "around for an exit. You then lay your eyes on a woman with dark braided hair and piercing purple \n"
				+ "eyes standing in front of what appears to be a door. She doesn’t move or say anything, but when you \n"
				+ "attempt to push past her you’re knocked back with a powerful shock of electricity. You’re not sure \n"
				+ "what you’ve gotten yourself into, but you have a feeling that you need to get out of here fast. The \n"
				+ "woman doesn’t look like she’s ready to attack yet but you feel a sense of urgency to get out of that \n"
				+ "room from the way that she glares at you.";
		
		EiChamber chamber = new EiChamber("This is the Shogun's chamber", intro, 30);
		new EscapeApp(chamber).runGame();
		
		
	}
}
