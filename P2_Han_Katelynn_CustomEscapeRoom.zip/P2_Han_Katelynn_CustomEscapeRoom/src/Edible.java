
public interface Edible {
	public void eat();
}
