/**
 *	Allows an item to use itself on another item
 * */
public interface UseableItemOn{
	
	//This item used on other item
	public void useOn(Item item);
}
