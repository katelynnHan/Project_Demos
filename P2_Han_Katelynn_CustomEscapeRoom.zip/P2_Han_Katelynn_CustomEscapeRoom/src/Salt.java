
public class Salt extends Food{
	public Salt() {
		super("salt", "The most important seasoning in the world!", true);
	}

	public void eat() {
		System.out.println("Why... would you eat salt straight up? But anyways you ate it and nothing really "
				+ "happened");
	}
}
