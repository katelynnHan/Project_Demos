import java.util.Scanner;

public class Element extends UselessItem implements CommandHandler, Reactable {
	private String element;

	private Room room;

	private Item itemAffected;

	public Element(String element) {
		this(element, element);

		this.element = element;
	}

	public Element(String name, String description) {
		super(name, description);
	}

	public boolean isValid(String element) {
		if (element.toLowerCase().equals("pyro") || element.toLowerCase().equals("cryo")
				|| element.toLowerCase().equals("hydro") || element.toLowerCase().equals("electro")
				|| element.toLowerCase().equals("none")) {
			return true;
		}

		return false;
	}

	public void setElement(String elem) {
		element = elem;
	}

	/**
	 * Returns the element
	 */
	public String getElement() {
		return element;
	}

	/**
	 * How this would react to another element
	 */
	@Override
	public void react(Element otherElement) {
		String elem1 = element;
		String elem2 = otherElement.getElement();

		if ((isPyro(elem1) && isCryo(elem2)) || (isPyro(elem2) && isCryo(elem1))) {
			System.out.println("You've triggered melt!");
		} else if ((isPyro(elem1) && isHydro(elem2)) || (isPyro(elem2) && isHydro(elem1))) {
			System.out.println("You've triggered vaporize!");
		} else if ((isPyro(elem1) && isElectro(elem2)) || (isPyro(elem2) && isElectro(elem1))) {
			System.out.println("You've triggered overload!");
		} else if ((isCryo(elem1) && isHydro(elem2)) || (isCryo(elem2) && isHydro(elem1))) {
			System.out.println("You've triggered freeze!");
		} else if ((isElectro(elem1) && isCryo(elem2)) || (isElectro(elem2) && isCryo(elem1))) {
			System.out.println("You've triggered superconduct!");
		}
	}

	// Checking elements
	public boolean isHydro(String str) {
		return str.equals("hydro");
	}

	public boolean isPyro(String str) {
		return str.equals("pyro");
	}

	public boolean isElectro(String str) {
		return str.equals("pyro");
	}

	public boolean isCryo(String str) {
		return str.equals("cryo");
	}

	/**
	 * Sets the room that this element is in
	 */
	public void setRoom(Room room) {
		this.room = room;
	}

	/**
	 * Sets the item that this element is affecting
	 */
	public void setItem(Item item) {
		itemAffected = item;
	}

	@Override
	public boolean execute(String command) {
		Scanner scan = new Scanner(command);

		if (scan.hasNext()) {
			String com = scan.next();

			if (com.equals("apply")) {
				if (scan.hasNext()) {
					String elemName = scan.next();

					Element elem = new Element(elemName);

					if (isValid(elemName)) {
						if (scan.hasNext() && scan.next().equals("to")) {
							String item1Name = scan.next();

							Item item = room.getItem(item1Name);

							if (item != null) {
								item.react(elem);

								return true;
							}
						}
					}
				}
			}
		}

		return false;
	}

	@Override
	public void printHelp() {
		System.out.println("You can try applying elements to items to trigger reactions!");
		System.out.println("You can try to use one item on another and see what happens!");
	}

	@Override
	public void setElement(Element element) {
		this.element = element.getElement();
	}
}
