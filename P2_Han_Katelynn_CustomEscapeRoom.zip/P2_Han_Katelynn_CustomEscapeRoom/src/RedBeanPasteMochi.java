
public class RedBeanPasteMochi extends Food implements UseableItemOn {
	public RedBeanPasteMochi() {
		super("red_bean_paste_mochi" , "A desert that's easy to make yet still delicious!", false);
	}

	@Override
	public void useOn(Item item) {
		if(item.getName().equals("raiden_shogun")) {
			RaidenShogun ei = (RaidenShogun)(item);
			
			ei.setDistraction(true);
			ei.speak();
		}else {
			super.useOn(item);
		}
	}
}
