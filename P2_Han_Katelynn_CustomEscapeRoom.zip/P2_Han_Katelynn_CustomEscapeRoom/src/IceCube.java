import java.util.Iterator;
import java.util.Scanner;

public class IceCube extends Container implements Reactable {
	/**
	 * The amount of "hits" it can take from electro/anemo/geo But if you apply
	 * pyro, it's instantly dropped to 0
	 */
	private int cubeHP;
	
	private Element element;

	public IceCube() {
		super("ice_cube",
				"A giant block of ice that doesn't seem to be \n"
						+ "melting despite the room temperature. There seems to \n" + "be sometime incased inside.",
				false, true);

		add(new Salt());
		add(new Food("crab", "A fresh crab! Really well preserved in the ice!", true));
		add(new Food("red_bean_paste", "Amazing stuffing that can go with any desert!", false));
		add(new Food("seaweed", "The stuff that you use to wrap sushi and stuff!", true));
		add(new Food("rice", "A necessity for life!", false));

		cubeHP = 3;

		setElement(new Element("cryo"));
	}

	@Override
	public void react(Element element) {
		if (element.getElement().equals("pyro")) {
			System.out.println("The ice cube has melted!");
			cubeHP = 0;
		} else if (element.getElement().equals("cryo") || element.getElement().equals("hydro")) {
			System.out.println("The ice cube got bigger!");
			cubeHP++;
		} else if (element.getElement().equals("electro")) {
			System.out.println("A puff of cold air breaks off from the " + "ice cube");
			cubeHP--;
		} else {
			System.out.println("Nothing happens!");
		}

		if (broken()) {
			onBreak();
		}
	}

	/**
	 * When you've either melted the ice (pyro), superconducted it until it's gone
	 * (cryo) 3 times, or crystalized it until it's gone (geo)
	 */
	public void onBreak() {
		unlock();
		open();
		System.out.println("You can now access the contents that were inside!");
		printContents();
		
		getRoom().remove(this);
	}

	/**
	 * Check if the ice cube has been broken
	 */
	public boolean broken() {
		if (cubeHP <= 0) {
			return true;
		}
		return false;
	}

	
	
	@Override
	public void use() {
		if (isLocked()) {
			System.out.println("You try break the ice but it's rock hard");
		} else {
			System.out.println("You discover some items that were previously incased in the ice:\n");
			for (int i = 0; i < getContents().size(); i++) {
				System.out.println(getContents().get(i));
				open();
			}
		}
	}

	public void eat() {
		System.out.println("You lick the ice cube, and it seems to have gotten smaller...?");
		cubeHP--;

		if (broken()) {
			onBreak();
		}
	}

	@Override
	public boolean execute(String command) {
		Scanner scan = new Scanner(command);

		if (scan.hasNext()) {
			String com = scan.next();
			if (scan.hasNext()) {
				if (com.equals("open")) {
					if (scan.next().equals(getName())) {
						if (!open()) {
							if (isLocked()) {
								System.out.println("You try to open the " + getName() + ", but it is locked.");
							} else {
								System.out.println("You open the " + getName() + ". Inside, you see: ");
								printContents();
								open();
							}
						} else {
							System.out.println("The " + getName() + " is already open.");
						}
						return true;
					}
				} else if (com.equals("close")) {
					if (scan.hasNext()) {
						if (scan.next().equals(getName())) {
							if (open()) {
								System.out.println("You close the " + getName());
								close();
							} else {
								System.out.println("The " + getName() + " is already closed.");
							}
							return true;
						}
					}
				} else if (com.equals("eat")) {
					if (scan.next().equals(getName())) {
						eat();

						return true;
					}
				}
			}
		}

		return false;
	}
	
	@Override
	public void printHelp() {

	}
	
	public void setElement(Element element) {
		this.element = element;
	}
}
