
public class RedBeanPasteMochiRecipe extends Recipe {
	public RedBeanPasteMochiRecipe() {
		super(false, "mochi", "red_bean_paste");
	}

	@Override
	public void combineInRoom(Room room) {
		System.out.println("You've created a red_bean_paste_mochi!");
		
		room.add(new RedBeanPasteMochi());
		
		removeIngredientsFromRoom(room);
	}
}
