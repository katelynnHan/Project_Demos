
public class WoodenHammer extends Item implements UseableItemOn {

	public WoodenHammer() {
		super("wooden_hammer", 
				"A wooden hammer that looks like the ones used to pound mochi");
	}

	/**
	 * Using this item on another item
	 * @param item The item that this is being used on
	 * */
	@Override
	public void useOn(Item item) {
		if(item.getName().equals("rice")) {
			System.out.println("You pound the rice for what seems like hours until it turns to\n"
					+ "a soft and dough like texture. \n"
					+ "...You've made mochi!");
			item.getRoom().add(new Food("mochi", "A Japanese food with a chewy texture! Perfect for making deserts with.", false));
			item.getRoom().remove(item);
		}else {
			super.useOn(item);
		}
	}

	@Override
	public void use() {
		System.out.println("You pick up the hammer but you're confused on what to do next");
	}

}
