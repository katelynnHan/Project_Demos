/**
 * If you call interact on the item, you can have a conversation with them
 * */
public interface Speakable {
	public void speak();
}
