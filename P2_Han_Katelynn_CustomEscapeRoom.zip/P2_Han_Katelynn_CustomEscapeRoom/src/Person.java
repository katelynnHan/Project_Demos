import java.util.Scanner;

public class Person extends UselessItem implements Speakable, CommandHandler {

	public Person(String name, String description) {
		super(name, description);
	}

	@Override
	public void speak() {
		System.out.println("Hi, my name is " + getName() + "!");
	}

	@Override
	public boolean execute(String command) {
		Scanner scan = new Scanner(command);
		
		if(scan.hasNext()) {
			if(scan.next().equals("speak_to")) {
				if(scan.hasNext() && scan.next().equals(getName())) {
					speak();
				}
				return true;
			}
		}

		return false;
	}

	@Override
	public void printHelp() {
		System.out.println("You can try to speak to " + getName());
	}
}
