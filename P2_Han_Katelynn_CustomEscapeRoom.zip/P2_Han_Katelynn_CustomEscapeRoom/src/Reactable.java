
public interface Reactable {
	public void react(Element element);
	
	public void setElement(Element element);
}
