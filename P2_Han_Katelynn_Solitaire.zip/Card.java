
public class Card implements Comparable<Card>
{
    /** String value that holds the symbol of the card.
    Examples: "A", "Ace", "10", "Ten", "Wild", "Pikachu"
     */
    private String symbol;

    /** int value that holds the value this card is worth */
    private int value;

    /** boolean value that determines whether this card is face up or down */
    private boolean isFaceUp; 
    
    /** int value that holds the suit for the card (1 for Spades, 2 for
       Hearts, 3 for Clubs, and 4 for Diamonds)*/
    private int suit;

    /**
     * Creates a new <code>Card</code> instance.
     *
     * @param symbol  a <code>String</code> value representing the symbol of the card
     * @param value an <code>int</code> value containing the point value of the card
     */    
    public Card(String symbol, int value, boolean isFaceUp) {
        this.symbol = symbol;
        this.value = value;
        this.isFaceUp = isFaceUp;
    }
    
    /**
     * Creates a new <code>Card</code> instance with suit.
     *
     * @param symbol  a <code>String</code> value representing the symbol of the card
     * @param value an <code>int</code> value containing the point value of the card
     * @param suit a <code>int</code> value containing the suit of the card (spade, heart, clubs, or dimaonds)
     */   
    public Card(String symbol, int value, int suit) {
        this.symbol = symbol;
        this.value = value;
        isFaceUp = false;
        this.suit = suit;
    }
    
    /**
     * Compares one card to another and returns the difference between the values
     * 
     * @param card The card object that is being compared
     * 
     * @return The difference between the values of the cards
     */
    @Override
    public int compareTo(Card card) {
        return Math.abs(card.getValue() - getValue());
    }

    /**
     * Getter method to access this <code>Card</code>'s symbol.
     * 
     * @return this <code>Card</code>'s symbol.
     */
    public String getSymbol() {
        return symbol;
    }
    
    /**
     * Getter method to access this <code>Card</code>'s suit.
     * 
     * @return this <code>Card</code>'s suit.
     */
    public int getSuit() {
        return suit;
    }

    /**
     * Getter method to access this <code>Card</code>'s value
     * 
     * @return this <code>Card</code>'s value
     */
    public int getValue() {
        return value;
    }
    
    /**
     * Checks if the card is face up
     * 
     * @return True if this card is face up, false if it's face down
     */
    public boolean isFaceUp() {
        return isFaceUp;
    }
    
    /**
     * Sets the card to the state that is passed in the parameter
     * 
     * @param state the state that the card will be set to
     */
    public void setFaceUp(boolean state) {
        isFaceUp = state;
    }
    
    /**
     * Sets the card's suit to the suit that is passed in the parameter
     * 
     * @param cardSuit the suit that the card will be set to
     */
    public void setSuit(int cardSuit) {
        suit = cardSuit;
    }

    /**
     * Returns whether or not this <code>Card</code> is equal to another
     *  
     *  @return whether or not this Card is equal to other.
     */
    public boolean equals(Card other) {
        if(value == other.getValue()) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Returns this card as a String.  If the card is face down, "X"
     * is returned.  Otherwise the symbol of the card is returned.
     *
     * @return a <code>String</code> containing the symbol or and X,
     * depending on whether the card is face up or down.
     */
    @Override
    public String toString() {
        if(isFaceUp) {
            return symbol;
        }
        
        return "X";
    }
}
