import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Deck
{
    //Arrays for the different attributes of cards
    
    private ArrayList<Card> deckOfCards;
    
    //Default constructor
    public Deck() {
        deckOfCards = new ArrayList<Card>();
    }
    
    //Constructor that takes the cards in the form of a string
    public Deck(String stringForm) {
        deckOfCards = new ArrayList<Card>();
        Scanner scan = new Scanner(stringForm);
        
        while(scan.hasNext()) {
            String symbol = scan.next();
            boolean isFaceUp = scan.nextBoolean();
            int value = scan.nextInt();
            
            Card card = new Card(symbol, value, isFaceUp);
            
            deckOfCards.add(card);
        }
    }
    
    //Adds a card
    public void add(Card card) {
        deckOfCards.add(card);
    }
    
    //Adds a deck
    public void add(Deck deck) {
        while(!deck.isEmpty()) {
            deckOfCards.add(deck.draw(0));
        }
    }
    
    public void shuffle() {
        ArrayList<Card> newList = deckOfCards;
        deckOfCards = new ArrayList<Card>();
        
        while(newList.size() > 0) {    
            Random rand = new Random();
            
            int newPos = rand.nextInt(newList.size());
            
            deckOfCards.add(newList.remove(newPos));
        }
    }
    
    //Empties the deck of cards
    public void emptyDeck() {
        for(int i = 0; i < deckOfCards.size(); i++) {
            deckOfCards.remove(0);
        }
    }
    
    //Removes from certain index1 (inclusive) to index2 (not inclusive) 
    //and returns it in a deck
    public Deck remove(int index1, int index2) {
        Deck newDeck = new Deck();
        int removeCards = index2 - index1;
        
        for(int i = 0; i < removeCards; i++) {
            Card removedCard = deckOfCards.remove(index1);
            
            newDeck.add(removedCard);
        }
        
        return newDeck;
    }
    
    //Removes from certain index1 (inclusive) to the end and returns it in a 
    //deck
    public Deck remove(int index1) {
        Deck newDeck = new Deck();
        
        int removeCards = deckOfCards.size() - index1;
        
        for(int i = 0; i < removeCards; i++) {
            Card removedCard = deckOfCards.remove(index1);
            
            newDeck.add(removedCard);
        }
        
        return newDeck;
    }
    
    //Returns a deck from certain index1 (inclusive to the end)
    public Deck cardSubstring(int index1) {
        Deck newDeck = new Deck();
        
        int removeCards = deckOfCards.size() - index1;
        
        for(int i = 0; i < removeCards; i++) {
            Card removedCard = getCardAt(index1 + i);
            
            newDeck.add(removedCard);
        }
        
        return newDeck;
    }
    
    //Draw method that removes and returns the top card in this 
    //deck
    public Card draw() {
        return deckOfCards.remove(deckOfCards.size() - 1);
    }
    
    //Draw method that removes and returns a card at index 
    public Card draw(int index) {
        return deckOfCards.remove(index);
    }
    
    //Returns the index at the first instance of symbol
    public int cardIndexOf(String symbol) {
        for(int i = 0; i < deckOfCards.size(); i++) {
            if(deckOfCards.get(i).getSymbol().equals(symbol)) {
                return i;
            }
        }
        
        return -1;
    }
    
    //Returns the card at index
    public Card getCardAt(int index) {
        return deckOfCards.get(index);
    }
    
    //Returns the number of cards in this deck
    public int numCards() {
        return deckOfCards.size();
    }
    
    //Reveal the top card (makes top card face up if 
    ///not already and returns it)
    public Card revealTopCard() {
        deckOfCards.get(deckOfCards.size() - 1).setFaceUp(true);
        
        return deckOfCards.get(deckOfCards.size() - 1);
    }
    
    //boolean isEmpty()
    public boolean isEmpty() {
        if(deckOfCards.size() == 0) {
            return true;
        }
        
        return false;
    }
    
    @Override
    public String toString() {
        String cardStr = "";
        for(int i = 0; i < deckOfCards.size(); i++) {
            cardStr += deckOfCards.get(i).toString() + ", ";
        }
        
        if(cardStr.length() > 0) {
            cardStr = cardStr.substring(0, cardStr.length() - 2);
        }
        
        cardStr = "[" + cardStr + "]";
        
        return cardStr;
    }
    
    //Returns the state of the deck as a string
    public String toStringState() {
        String newStr = "";
        
        for(int i = 0; i < numCards(); i++) {
            String symbol = deckOfCards.get(i).getSymbol();
            boolean isFaceUp = deckOfCards.get(i).isFaceUp();
            int value = deckOfCards.get(i).getValue();
            
            newStr += symbol + " " + isFaceUp + " " + value + " ";
        }
        
        return newStr;
    }
}
