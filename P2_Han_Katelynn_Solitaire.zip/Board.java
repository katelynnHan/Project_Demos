import java.util.ArrayList;
public class Board
{   
    //ArrayLists that contains the symbols and values of cards
    private ArrayList<String> symbols = new ArrayList<String>(13);
    private ArrayList<Integer> values = new ArrayList<Integer>(13);
    
    private Deck referenceDeck = new Deck(); //Deck that is used to check
    //if a stack has a full run

    // Attributes
    /**
    An ArrayList of decks that represent the amount of stacks the player has 
    to work with on the board
       */
    private ArrayList<Deck> stacks;
    
    /**
    A deck that represents draw pile that the player can draw from
       */
    private Deck drawPile;
    
    /**
    An ArrayList of decks that represent the completed stacks
       */
    private ArrayList<Deck> completedStacks;
    
    /**
     *  Sets up the Board and fills the stacks and draw pile from a Deck
     *  consisting of numDecks Decks.  Here are examples:
     *  
     *  # numDecks     #cards in overall Deck
     *      1          13 (all same suit)
     *      2          26 (all same suit)
     *      3          39 (all same suit)
     *      4          52 (all same suit)
     *      
     *  Once the overall Deck is built, it is shuffled and half the cards
     *  are placed as evenly as possible into the stacks.  The other half
     *  of the cards remain in the draw pile.
     *  
     *  @param numStacks The number of stacks the player has to work with in
     *  the game
     *  @param numDecks The number of decks (13 cards) there are in the game
     */    
    public Board(int numStacks, int numDecks) {
        initializeLists();
        referenceDeck = addSuit();
        
        //Initializing Attributes
        drawPile = new Deck();
        stacks = new ArrayList<Deck>();
        completedStacks = new ArrayList<Deck>();
        
        //Adding the number of decks to the draw pile
        for(int i = 0; i < numDecks; i++) {
            drawPile.add(addSuit());
        }
        
        drawPile.shuffle(); //shuffling the draw pile
        
        //Dividing amount of cards in half
        int numDrawPileCards = drawPile.numCards()/2;
        
        Deck tempDeck = drawPile.remove(numDrawPileCards); //temporary deck 
        //to contian the cards that will be put into stacks
        
        System.out.println(tempDeck);
        
        for(int i = 0; i < numStacks; i++) { 
            //Adding empty decks to the stacks
            stacks.add(new Deck());
        }
        
        //While temp deck isn't empty, keep diving the cards into the stacks
        int stackNum = 0; //Variable keeping track of which stack it's on
        while(!tempDeck.isEmpty()) {
            Deck currentDeck = stacks.get(stackNum);
            
            currentDeck.add(tempDeck.draw());
            
            stackNum ++;
            
            if(stackNum > numStacks - 1) {
                stackNum = 0;
            }
        }
    }
    
    /**
     *  Sets up the Board when loading from a file. Takes in an ArrayList
     *  that represents the stacks, a Deck representing the draw pile, and an
     *  ArrayList representing the completed Stacks
     *  
     *  @param stacks The stacks of cards
     *  @param drawPile The draw pile
     *  @param completedStacks The completedStacks
     */    
    public Board(ArrayList<Deck> stacks, Deck drawPile, ArrayList<Deck> 
    completedStacks) {
        initializeLists();
        referenceDeck = addSuit();
        
        //Initializing Attributes
        this.drawPile = drawPile;
        this.stacks = stacks;
        this.completedStacks = completedStacks;
    }
    
    //A method that initializes the lists containing the symbols/values
    private void initializeLists() {
        //For the symbols
        for(int i = 2; i <= 10; i++) {
            symbols.add(i - 2, (12 - i) + "");
        }
        
        symbols.add("A");
        symbols.add(0, "K");
        symbols.add(1, "Q");
        symbols.add(2, "J");
        
        //For the values
        for(int i = 13; i >= 1; i --) {
            values.add(new Integer(i));
        }
    }
    
    /**
     * Returns the deck of cards in the stacks at index
     * 
     * @param index The index of the deck in the stack
     * @return The deck in the stacks at index 
     */
    public Deck getDeckInStack(int index) {
        if(index >= 0 && index < stacks.size()) {
            return stacks.get(index);
        }
        
        return null;
    }
    
    /**
     * Returns the draw pile
     * 
     * @return Returns the draw pile
     */
    public Deck getDrawPile() {
        return drawPile;
    }
    
    /**
     * Returns the number of completed stacks
     * 
     * @return Returns the number of completed stacks
     */
    public int getNumCompletedStacks() {
        return completedStacks.size();
    }
    
    /**
     * Returns the completed pile at index
     * 
     * @param index The index of the completed pile
     * @return Returns the completed pile
     */
    public Deck getCompletedPile(int index) {
        if(index >= 0 && index < stacks.size()) {
            return completedStacks.get(index);
        }
        
        return null;
    }
    
    /**
     * Checks if there is a run from index to the end
     */
    
    public boolean isRun(Deck deck, int index) {
        if(deck.numCards() - index <= 12) {
            Deck tempDeck = deck.cardSubstring(index); //cut down the string have
            //the symbol of interest at the start
        
            String symbol = deck.getCardAt(index).getSymbol(); //symbol of
            //interest
    
            int referenceIndex = referenceDeck.cardIndexOf(symbol); //index of
            //the symbol of interest
        
            Deck tempReferenceDeck = referenceDeck.cardSubstring(referenceIndex);
            //cutting down reference deck to be the same as deck


            if(tempReferenceDeck.numCards() >= tempDeck.numCards()) {
                for(int i = 0; i < tempDeck.numCards(); i++) {
                    if(!(tempDeck.getCardAt(i).getSymbol().equals(tempReferenceDeck.
                    getCardAt(i).getSymbol()))) {
                        return false;
                    }
                }
                
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Returns a boolean for whether the deck that the current stack is being
     * moved too will form a run with the new deck
     * 
     * @param startDeck The deck that is being moved
     * @param endDeck The destination deck
     * @param index The index of the starting deck that is being used where
     * the symbol of interest is
     * @return returns whether the starting deck at index will make a run
     * with endDeck
     */
    public boolean willBeRun(Deck startDeck, Deck endDeck, int index) {
        if(isRun(startDeck, index)) {
            //If the endDeck is empty, then the move is legal
            if(endDeck.numCards() == 0) {
                return true;
            }
            String symbol = startDeck.getCardAt(index).getSymbol();
            //Symbol of interest
            int indexOfSymbol = referenceDeck.cardIndexOf(symbol); 
            //The index in reference deck of the symbol
            
            if(!(symbol.equals("K"))) {
                String nextSymbol = referenceDeck.getCardAt(
                indexOfSymbol - 1).getSymbol();
                
                //The last card (the card that is the destination)
                //in the end deck
                Card lastCard = endDeck.getCardAt(endDeck.numCards() - 1);
                
                if(lastCard.getSymbol().equals(nextSymbol) && 
                lastCard.isFaceUp()) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * In each stack of cards, flip the first card to face up
     */
    public void flipAllFirstCards() {
        for(int i = 0; i < stacks.size(); i++) {
            Deck currentDeck = stacks.get(i);
            
            if(currentDeck.numCards() > 0) {
                Card frontCard = 
                currentDeck.getCardAt(currentDeck.numCards() - 1);
                
                frontCard.setFaceUp(true);
            }
        }
    }
    
    /**
     * Adds 13 cards with no suit (face down) and returns a deck with those cards 
     */
    public Deck addSuit() {
        Deck newDeck = new Deck();
        
        for(int i = 0; i < 13; i++) {
            newDeck.add(new Card(symbols.get(i) + "", values.get(i), false));
        }
        
        return newDeck;
    }
    
    /**
     * Adds 13 cards with a specific suit (face down) and returns a deck with those cards
     * 
     * @param suit the suit that the player wishes to make a deck of
     * @return the deck that is made will be returned
     */
    public Deck addSuit(int suit) {
        Deck newDeck = new Deck();
        
        for(int i = 0; i < 13; i++) {
            newDeck.add(new Card(symbols.get(i) + "", values.get(i), suit));
        }
        
        return newDeck;
    }

    /**
     *  Moves a run of cards from src to dest (if possible) and flips the
     *  next card if one is available.
     *  
     *  @param symbol the card symbol that we search for
     *  @param src the stack that we search in
     *  @dest the destination that the card and (if there is a run)
     *  everything below it is moved
     */
    public void makeMove(String symbol, int src, int dest) {
        if((src >= 0 && src < stacks.size()) && (dest >= 0 &&
        dest < stacks.size())) {
            int index = -1;
            
            for(int i = stacks.get(src).numCards() - 1; i >= 0; i--) {
                //If the card at index i equals the symbol AND if it's face
                //up
                if(stacks.get(src).getCardAt(i).getSymbol().equals(symbol) &&
                (stacks.get(src).getCardAt(i).isFaceUp())) {
                    index = i;
                    break;
                }
            }
            
            if(index > -1 && willBeRun(stacks.get(src), stacks.get(dest),
            index)) {
                Deck movingDeck = stacks.get(src).remove(index);
                
                stacks.get(dest).add(movingDeck);
            }else if(index == - 1) { //If there is not a valid run from index
                System.out.println("Invalid: There is no visible " + 
                symbol + " card in the stack!");
            }else if(!isRun(stacks.get(src), index)) {
                System.out.println("Invalid: Not a run from " + symbol + 
                "!");
            }else{
                System.out.println("Invalid: Your move from stack " + 
                (src + 1) + " to stack " + (dest + 1) + 
                " doesn't make a valid stack!");
            }
        }
    }

    /** 
     *  Moves one card onto each stack, or as many as are available
     */
    public void drawCards() {
        boolean ableToDraw = true; //boolean to keep track of if all the 
        //stacks are full
        
        for(int i = 0; i < stacks.size(); i++) {
            if(stacks.get(i).numCards() == 0) {
                ableToDraw = false;

            }
        }
        
        if(ableToDraw) {
            for(int i = 0; i < stacks.size(); i++) {
                if(drawPile.numCards() > 0) {
                    Card drawnCard = drawPile.draw();
                    drawnCard.setFaceUp(true);
                
                    stacks.get(i).add(drawnCard);
                }
            }
            
            if(drawPile.numCards() == 0) {
                System.out.println("No more cards left to draw!");
            }
        }else if(!ableToDraw && drawPile.numCards() > 0) {
            System.out.println("Please fill all stacks before drawing!");
        }
    }

    /**
     *  Returns true if all stacks and the draw pile are all empty
     *  
     *  @return Returnes true if all stacks and the draw pile are empty
     */ 
    public boolean isEmpty() {
        boolean emptyStacks = true;
        boolean emptyDrawPile = true;
        
        for(int i = 0; i < stacks.size(); i++) {
            if(!(stacks.get(i).numCards() == 0)) {
                emptyStacks = false;
            }
        }
        
        if(!(drawPile.numCards() == 0)) {
            emptyDrawPile = false;
        }
        
        if(emptyStacks && emptyDrawPile) {
            return true;
        }
        
        return false;
    }

    /**
     *  If there is a run of A through K starting at the end of sourceStack
     *  then the run is removed from the game or placed into a completed
     *  stacks area.
     *  
     *  If there is not a run of A through K starting at the end of sourceStack
     *  then an invalid move message is displayed and the Board is not changed.
     *  
     *  @param sourceStack the stack that will be cleared (if there is a 
     *  full run)
     */
    public void clear(int sourceStack) {
        boolean isFullRun = true;
        Deck currentStack = new Deck();
        if(sourceStack >= 0 && sourceStack < stacks.size()) { //If the source
            //stack index is in bounds
            currentStack = stacks.get(sourceStack);
            
            if(currentStack.numCards() >= 13) { //If the stack has the right
                //amount of cards in the stack
                int offSet = currentStack.numCards() - 13;
                
                for(int i = 0; i < referenceDeck.numCards(); i++) {
                    if((!(referenceDeck.getCardAt(i).
                    equals(currentStack.getCardAt(offSet + i)))) ||
                    !currentStack.getCardAt(offSet + i).isFaceUp()) {
                        isFullRun = false;
                    }
                }
                
                if(isFullRun) {
                    Deck completedStack = currentStack.remove(
                    currentStack.numCards() - 13);
            
                    completedStacks.add(completedStack);
                }else{
                    System.out.println("Invalid: not a full run!");
                }
            }else{
                System.out.println("Invalid: not a full run!");
            }
        }else{
            System.out.println("Invalid: Not a valid stack!");
        }
    }

    /**
     * Prints the board to the terminal window by displaying the stacks, draw
     * pile, and done stacks (if you chose to have them)
     */
    public void printBoard() {
        System.out.println("Stacks: ");
        for(int i = 0; i < stacks.size(); i++) {
            System.out.println((i + 1) + ": " + stacks.get(i).toString());
        }
        
        System.out.println();
        
        System.out.println("Draw Pile: ");
        System.out.println(drawPile.toString());
        
        System.out.println();
        
        System.out.println("Completed Stacks: ");
        for(int i = 0; i < completedStacks.size(); i++) {
            System.out.println((i + 1) + ": " + 
            completedStacks.get(i).toString());
        }
    }
}