import java.util.ArrayList;
public class DeckTester
{
    private static ArrayList<String> symbols = new ArrayList<String>();
    private static ArrayList<Integer> values = new ArrayList<Integer>();
    
    public static void main(String[] args) {
        //For the symbols
        for(int i = 2; i <= 10; i++) {
            symbols.add(i + "");
        }
        
        symbols.add(0, "A");
        symbols.add(10, "J");
        symbols.add(11, "Q");
        symbols.add(12, "K");
        
        //For the values
        for(int i = 1; i <= 13; i++) {
            values.add(i);
        }
        
        Deck deck = new Deck();
       
        System.out.println(deck.toString());
       
        deck.add(new Card("A", 1, false));
       
        System.out.println(deck.toString());
       
        deck.emptyDeck();
        
        for(int i = 0; i < 13; i++) {
            deck.add(new Card(symbols.get(i) + "", values.get(i), true));
            
            deck.getCardAt(i).setFaceUp(true);
        }
       
        System.out.println(deck.toString());
       
        deck.shuffle();
       
        System.out.println(deck.toString());
       
        System.out.println(deck.remove(3, 5));
       
        System.out.println(deck.toString());
       
        System.out.println("Removing from index 2: " + deck.remove(2));
       
        System.out.println(deck.toString());
        
        Deck newDeck = new Deck();
        
        for(int i = 0; i < 4; i++) {
            Card newCard = new Card(symbols.get(i), values.get(i), true);
            newCard.setFaceUp(true);
            
            newDeck.add(newCard);
        }
        
        System.out.println(newDeck.toString());
        
        deck.add(newDeck);
        
        System.out.println(deck.toString());
        
        System.out.println(deck.cardSubstring(3));
        
        String deckToString = deck.toStringState();
        
        System.out.println(deckToString);
        
        Deck newnewDeck = new Deck(deckToString);
        
        System.out.println("Deck: " + deck);
        
        System.out.println("New Deck: " + newnewDeck);
    }
}
