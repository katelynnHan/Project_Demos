import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.File;
import javax.swing.JFileChooser;
import java.io.IOException;
import java.awt.EventQueue;
import javax.swing.JFileChooser;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

public class SpiderSolitaire
{
    /** Number of stacks on the board **/
    public final int NUM_STACKS = 7;

    /** Number of complete decks used in this game.  A 1-suit deck, which is the
     *  default for this lab, consists of 13 cards (Ace through King).
     */
    public final int NUM_DECKS = 4;

    /** A Board contains stacks and a draw pile **/
    private Board board;

    /** Used for keyboard input **/
    private Scanner input;

    public SpiderSolitaire()
    {
        // Start a new game with NUM_STACKS stacks and NUM_DECKS of cards
        board = new Board(NUM_STACKS, NUM_DECKS);
        input = new Scanner(System.in);
    }

    /** Main game loop that plays games until user wins or quits **/
    public void play() {

        board.flipAllFirstCards();
        board.printBoard();
        boolean gameOver = false;

        while(!gameOver) {
            System.out.println("\nCommands:");
            System.out.println("   move [card] [source_stack] [destination_stack]");
            System.out.println("   draw");
            System.out.println("   clear [source_stack]");
            System.out.println("   restart");
            System.out.println("   save");
            System.out.println("   load");
            System.out.println("   quit");
            System.out.print(">");
            String command = input.next();

            if (command.equals("move")) {
                String symbol = input.next();

                boolean sourceSetValue = false; //If the source stack was 
                //set a value by the player (not the default value)
                boolean destinationSetValue = false; //If the destination 
                //stack was set a value by the player (not the default value)

                int sourceStack = -1;
                int destinationStack = -1;

                try{
                    sourceStack = input.nextInt();
                    sourceSetValue = true;
                }catch(InputMismatchException e) {
                    System.out.println("Invalid: Not a valid source stack " 
                        + "value!");
                    input.next();
                }

  
                try{
                    destinationStack = input.nextInt();
                    destinationSetValue = true;
                }catch(InputMismatchException e) {
                    System.out.println("Invalid: Not a valid destination " + 
                        "stack value!");
                }

                if(sourceSetValue && (sourceStack <= 0 || 
                    sourceStack > NUM_STACKS)) {
                    System.out.println("Invalid: Not a valid source stack " 
                        + "value!");
                }

                if(destinationSetValue && (destinationStack <= 0 ||
                    sourceStack > NUM_STACKS)) {
                    System.out.println("Invalid: Not a valid destination " + 
                        "stack value!");
                }

                if((destinationStack > 0) && (sourceStack > 0) &&
                (destinationStack <= NUM_STACKS) && 
                (sourceStack <= NUM_STACKS)) {
                    board.makeMove(symbol, sourceStack - 1, 
                        destinationStack - 1);
                }

                input.nextLine();
            }else if (command.equals("draw")) {
                board.drawCards();
            }else if (command.equals("clear")) {
                int sourceStack = -1;

                try{
                    sourceStack = input.nextInt();
                }catch(InputMismatchException e) {
                    System.out.println("Invalid imput for sourceStack!");
                }
                board.clear(sourceStack - 1);
            }else if (command.equals("restart")) {
                board = new Board(NUM_STACKS, NUM_DECKS);
            }else if (command.equals("save")) {
                save();
            }else if(command.equals("load")) {
                load();
            }else if (command.equals("quit")) {
                System.out.println("Goodbye!");
                System.exit(0);
            }else {
                System.out.println("Invalid command.");
            }

            board.flipAllFirstCards();
            board.printBoard();

            // If all stacks and the draw pile are clear, you win!
            if (board.isEmpty()) {
                gameOver = true;
            }
        }
        System.out.println("Congratulations!  You win!");
    }

    public void save() {
        try {
            EventQueue.invokeAndWait(new Runnable() {
                    @Override
                    public void run() {
                        JFileChooser chooser = new JFileChooser();

                        chooser.showSaveDialog(null);

                        File fileName = chooser.getSelectedFile();

                        FileWriter writer = null;

                        if(fileName != null) {
                            System.out.println("File name isn't null");

                            try{
                                writer = new FileWriter(fileName);
                            }catch(IOException e) {
                                System.out.println("File does not exist");
                            }
                        }

                        if(writer != null) {
                            //For the stacks
                            for(int i = 0; i < NUM_STACKS; i++) {
                                Deck currentDeck = board.getDeckInStack(i);

                                try{
                                    writer.write(currentDeck.toStringState() + 
                                        "\n");
                                }catch(IOException e) {
                                    System.out.println(e.getMessage());
                                }
                            }

                            //For the draw pile
                            try{
                                writer.write(board.getDrawPile().toStringState() 
                                    + "\n");
                            }catch(IOException e) {
                                System.out.println(e.getMessage());
                            }

                            //For the completed stacks

                            System.out.println("CompletedStacks: " + board.getNumCompletedStacks());
                            for(int i = 0; i < board.getNumCompletedStacks(); 
                            i++) {
                                try{
                                    Deck currentDeck = 
                                        board.getCompletedPile(i);

                                    writer.write(currentDeck.toStringState() + 
                                        "\n");
                                }catch(IOException e) {
                                    System.out.println(e.getMessage());
                                }
                            }
                        }

                        try{
                            writer.close();
                        }catch(IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                });
        }catch (InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
        }catch (InvocationTargetException e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void load() {
        try {
            EventQueue.invokeAndWait(new Runnable() {
                    @Override
                    public void run() {
                        JFileChooser chooser = new JFileChooser();

                        chooser.showOpenDialog(null);

                        File selectedFile = chooser.getSelectedFile();

                        Scanner scan = null;
                        try{
                            scan = new Scanner(selectedFile);
                        }catch(FileNotFoundException e) {
                            System.out.println(e.getMessage());   
                        }

                        if(scan != null) {
                            //The stacks
                            ArrayList<Deck> stacks = new ArrayList<Deck>();
                            for(int i = 0; i < NUM_STACKS; i++) {
                                String deckString = scan.nextLine();

                                Deck deck = new Deck(deckString);

                                stacks.add(deck);
                            }

                            //The draw pile
                            String drawPileString = scan.nextLine();

                            Deck drawPile = new Deck(drawPileString);

                            //Completed stacks 
                            ArrayList<Deck> completedStacks = 
                                new ArrayList<Deck>();
                            while(scan.hasNext()) { 
                                String completedStackString = scan.nextLine();

                                Deck deck = new Deck(completedStackString);

                                completedStacks.add(deck);
                            }

                            board = new Board(stacks, drawPile, completedStacks);
                        }
                    }
                });
        }
        catch (InterruptedException e) {
            System.out.println("Error: " + e.getMessage());
        }
        catch (InvocationTargetException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
