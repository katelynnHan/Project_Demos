public class CardTester
{
    public static void main(String[] args) {
        Card card1 = new Card("5", 5, true);
        Card card2 = new Card("6", 6, true);
        Card card3 = new Card("3", 3, true);
        Card card4 = new Card("A", 1, true);
        Card card5 = new Card("3", 3, true);
        
        System.out.println("Card 1's symbol: " + card1.getSymbol());
        
        System.out.println("Card 2's value: " + card2.getValue());
        
        System.out.println("Difference between card 2 and 3's values: " + 
        card2.compareTo(card3));
        
        card3.setFaceUp(false);
        System.out.println("Set card 3 to face down");
        System.out.println("Is card 3 face up? " + card3.isFaceUp());
        
        System.out.println("Is card 3 and 5 equal? " + card3.equals(card5));
        
        System.out.println("To string for card 2: " + card2.toString());
        System.out.println("To string for card 3: " + card3.toString());
    }
}
