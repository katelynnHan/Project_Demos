import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class P2_Han_Katelynn_LifeGUI_2 extends Application implements GenerationListener {
	P2_Han_Katelynn_LifeModel model;
	BooleanGridPane view;
	Slider sizeSlider;
	Slider delaySlider;
	Button clearButton;
	Button loadButton;
	Button nextGenButton;
	Label genLabel;
	ToggleButton playButton;
	double delay;
	double maxHeight;
	double maxWidth;

	public static void main(String[] args) {
		launch();
	}

	@Override
	public void start(Stage stage) throws Exception {
		Boolean[][] data = { { true, true, true, false }, { false, true, false, true }, { false, true, false, false } };
		model = new P2_Han_Katelynn_LifeModel(data);
		BorderPane root = new BorderPane();

		model.addGenerationListener(this);

		// Bottom pane
		HBox bottomPane = new HBox();
		bottomPane.setAlignment(Pos.CENTER);
		bottomPane.setPrefHeight(80);
		BackgroundFill[] fills = { new BackgroundFill(Color.GRAY, new CornerRadii(0), new Insets(0)) };
		bottomPane.setBackground(new Background(fills));
		HBox bottomRightTopPane = new HBox(5);
		HBox bottomRightBottomPane = new HBox(5);
		VBox bottomRightPane = new VBox(5);
		clearButton = new Button("Clear");
		nextGenButton = new Button("Next Generation");
		genLabel = new Label("Current Gen: " + model.getGeneration());

		genLabel.setBackground(new Background(
				new BackgroundFill((Paint) Color.rgb(255, 255, 255), new CornerRadii(0), new Insets(0))));
		sizeSlider = new Slider(5, 100, 50);
		
		//Delay stuff
		MyAnimationTimer aTimer = new MyAnimationTimer();
		playButton = new ToggleButton("Play");
		playButton.selectedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if(newValue) {
					aTimer.start();
				}else {
					aTimer.stop();
				}
			}
		});
		
		delaySlider = new Slider(0, 100, 50);
		delay = delaySlider.valueProperty().doubleValue()/100.0;
		Label delayLabel = new Label("Current delay: " + delay);
		delaySlider.valueProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				delay = newValue.doubleValue()/100;
				DecimalFormat df = new DecimalFormat("#.##");
				delayLabel.setText("Current delay: " + df.format(delay));
			}
		});
		
		Label label = new Label("Cell size");
		bottomRightTopPane.getChildren().addAll(clearButton, nextGenButton, genLabel);
		bottomRightBottomPane.getChildren().addAll(delaySlider, delayLabel, playButton);
		bottomRightPane.getChildren().addAll(bottomRightTopPane, bottomRightBottomPane);
		bottomRightPane.setPadding(new Insets(15));
		bottomPane.getChildren().addAll(bottomRightPane, sizeSlider, label);

		MenuBar mBar = new MenuBar();
		Menu menu = new Menu("File");
		MenuItem openItem = new MenuItem("Open");
		MenuItem saveItem = new MenuItem("Save");

		menu.getItems().addAll(openItem, saveItem);
		mBar.getMenus().add(menu);

		root.setTop(mBar);

		root.setBottom(bottomPane);

		// Boolean grid pane (top pane)
		view = new BooleanGridPane();
		maxHeight = 450;
		maxWidth = 450;

		view.setModel(model);
		root.setCenter(view);

		MyChangeListener list = new MyChangeListener();

		sizeSlider.valueProperty().addListener(list);

		MyLoadHandler mouse = new MyLoadHandler();
		openItem.setOnAction(mouse);

		MySaveHandler sHand = new MySaveHandler();
		saveItem.setOnAction(sHand);

		MyMouseListener mouseL = new MyMouseListener();
		view.setOnMouseDragged(mouseL);
		view.setOnMouseClicked(mouseL);

		MyClearListener clearing = new MyClearListener();
		clearButton.setOnMousePressed(clearing);

		MyNextGenListener genList = new MyNextGenListener();
		nextGenButton.setOnMousePressed(genList);

		Scene scene = new Scene(root);

		stage.setScene(scene);

		stage.setWidth(550);
		stage.setHeight(600);

		stage.show();
	}

	private class MyMouseListener implements EventHandler<MouseEvent> {
		@Override
		public void handle(MouseEvent event) {
			double x = event.getX();
			double y = event.getY();

			int rowForY = view.rowForYPos(y);
			int colForX = view.colForXPos(x);

			if (rowForY < model.getNumRows() && colForX < model.getNumCols() && colForX >= 0 && rowForY >= 0) {
				if (event.getButton() == MouseButton.PRIMARY) {
					model.setValueAt(rowForY, colForX, true);
				} else if (event.getButton() == MouseButton.SECONDARY) {
					model.setValueAt(rowForY, colForX, false);
				}
			}

			view.resetCells();
		}
	}

	private class MyClearListener implements EventHandler<MouseEvent> {
		@Override
		public void handle(MouseEvent event) {
			for (int i = 0; i < model.getNumRows(); i++) {
				for (int j = 0; j < model.getNumCols(); j++) {
					model.setValueAt(i, j, false);
				}
			}
			model.setGeneration(0);
			genLabel.setText("Current Gen: " + 0);
			view.resetCells();
		}
	}

	private class MyNextGenListener implements EventHandler<MouseEvent> {
		@Override
		public void handle(MouseEvent event) {
			model.nextGeneration();
		}
	}

	private class MyChangeListener implements ChangeListener<Number> {
		@Override
		public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
			double width = (double) (newValue) * model.getNumRows();
			double height = (double) (newValue) * model.getNumCols();
			double cellSize = 0;

			if (width <= maxWidth && height <= maxHeight) {
				view.setTileSize(newValue.doubleValue());
			} else if (width > maxWidth && model.getNumCols() >= model.getNumRows()) {
				view.setTileSize(maxWidth / model.getNumCols());
			} else if (height > maxHeight && model.getNumRows() >= model.getNumCols()) {
				view.setTileSize(maxHeight / model.getNumRows());
			}

			view.resetCells();
		}
	}

	private class MyLoadHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			FileChooser fileChooser = new FileChooser();

			File file = fileChooser.showOpenDialog(null);

			if (file != null) {
				load(file);
			}
		}

		private void load(File file) {
			Scanner scan = new Scanner("hi");

			try {
				scan = new Scanner(file);
			} catch (FileNotFoundException e) {
				System.out.println("Error");
				e.printStackTrace();
			}

			int numRows = Integer.parseInt(scan.next());
			int numCols = Integer.parseInt(scan.next());

			Boolean[][] newGrid = new Boolean[numRows][numCols];

			scan.nextLine();

			for (int i = 0; i < numRows; i++) {
				for (int j = 0; j < numCols; j++) {
					String currentCell = scan.next();

					boolean currentCellVal = false;

					if (currentCell.equals("X")) {
						currentCellVal = true;
					} else if (currentCell.equals("O")) {
						currentCellVal = false;
					}

					newGrid[i][j] = currentCellVal;
				}

				scan.nextLine();
			}

			model.setGrid(newGrid);
		}
	}

	private class MySaveHandler implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			FileChooser fileChooser = new FileChooser();

			File file = fileChooser.showSaveDialog(null);

			FileWriter writer = null;
			try {
				writer = new FileWriter(file);
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (file != null && writer != null) {
				write(file, writer);
			}
		}

		private void write(File f, FileWriter writer) {
			try {
				writer.write(model.getNumRows() + " " + model.getNumCols() + "\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
			for (int i = 0; i < model.getNumRows(); i++) {
				for (int j = 0; j < model.getNumCols(); j++) {
					String value = model.getValueAt(i, j) ? "X" : "O";

					try {
						writer.write(value + " ");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

				try {
					writer.write("\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			try {
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private class MyAnimationTimer extends AnimationTimer {
		long oldTime = 0;

		@Override
		public void handle(long now) {
			if(now - oldTime >= 1e9 * delay) {
				oldTime = now;
				model.nextGeneration();
			}
		}
	}

	@Override
	public void generationChanged(int oldVal, int newVal) {
		genLabel.setText("Current Gen: " + newVal);
	}
}
