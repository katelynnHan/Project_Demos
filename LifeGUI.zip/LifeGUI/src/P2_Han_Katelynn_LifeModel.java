import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class P2_Han_Katelynn_LifeModel extends GridModel<Boolean> {
	Scanner scan;
	static FileWriter writer;
	int generation;
	ArrayList<GenerationListener> genLists;
	
	public P2_Han_Katelynn_LifeModel(Boolean[][] gridData) {
		super(gridData);
		genLists = new ArrayList<GenerationListener>();
		setGeneration(0);
	}
	
	public void runLife(int numGenerations) {
		for(int i = 0; i < numGenerations; i++) {
			nextGeneration();
		}
	}

	// Intializes the board with living cells
	public void initializeLifeBoard() {
		while (scan.hasNext()) {
			int row = scan.nextInt();
			int col = scan.nextInt();

			if (row < getNumRows() && col < getNumCols()) {
				setValueAt(row, col, true);
			}
		}
	}

	// Number of living cells in a certain row
	public int rowCount(int row) {
		int numAlive = 0;
		if (row >= 0 && row <= getNumRows()) {
			for (int i = 0; i < getNumCols(); i++) {
				if (getValueAt(row, i)) {
					numAlive++;
				}
			}

			return numAlive;
		}

		return -1;
	}

	// Number of living cells in a certain column
	public int colCount(int col) {
		int numAlive = 0;
		if (col >= 0 && col <= getNumCols()) {
			for (int i = 0; i < getNumRows(); i++) {
				if (getValueAt(i, col)) {
					numAlive++;
				}
			}

			return numAlive;
		}

		return -1;
	}
	
	//returns the total amount of living cells
	public int totalCount() {
		int living = 0;
		for(int row = 0; row < getNumRows(); row++) {
			for(int col = 0; col < getNumCols(); col++) {
				if(getValueAt(row, col)) {
					living ++;
				}
			}
		}
		
		return living;
	}

	// Advances the board one generation
	public void nextGeneration() {
		Boolean[][] nextGen = new Boolean[getNumRows()][getNumCols()];
		
		for(int row = 0; row < getNumRows(); row++) {
			for(int col = 0; col < getNumCols(); col++) {
				int numNeighbors = 0;
				
				if(row >= 1) { //row above
					
					if(getValueAt(row - 1, col)) { //cell above
						numNeighbors ++;
					}
					
					if(col >= 1 && getValueAt(row - 1, col - 1)) {//top left
						numNeighbors ++;
					}
					
					if(col < getNumCols() - 1 && getValueAt(row - 1, col + 1)) { //top right
						numNeighbors ++;
					}
				}
				
				if(col >= 1 && getValueAt(row, col - 1)) { //directly left
					numNeighbors ++;
				}
				
				if(col < getNumCols() - 1 && getValueAt(row, col + 1)) {
					//directly right
					numNeighbors ++;
				}
				
				if(row < getNumRows() - 1) { //row below 
					if(getValueAt(row + 1, col)) { //directly below
						numNeighbors ++;
					}
					
					if(col >= 1 && getValueAt(row + 1, col - 1)) { 
						//bottom left
						numNeighbors ++;
					}
					
					if(col < getNumCols() - 1 && 
							getValueAt(row + 1, col + 1)) { //bottom right
						numNeighbors ++;
					}
				}
				
				if(getValueAt(row, col)) {
					if(numNeighbors <= 1 || numNeighbors >= 4) {
						nextGen[row][col] = false;
					}else if(numNeighbors == 2 || numNeighbors == 3) {
						nextGen[row][col] = true;
					}
				}else if(!getValueAt(row, col)) {
					if(numNeighbors == 3) {
						nextGen[row][col] = true;
					}else {
						nextGen[row][col] = false;
					}
				}
			}
		}
		
		setGeneration(getGeneration() + 1);
		setGrid(nextGen);
	}

	// Prints the board
	public void printBoard() {
		System.out.print("  ");
		for (int i = 0; i < getNumRows(); i++) {
			if(i < 10) {
				System.out.print(i);
			}else {
				System.out.print(i - 10);
			}
		}
		System.out.println();
		for (int row = 0; row < getNumRows(); row++) {
			System.out.print(row + " ");
			
			for (int col = 0; col < getNumCols(); col++) {
				if (getValueAt(row, col)) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	// Prints the total number of living cells in a certain row
	public void printRowCount(int row) {
		System.out.printf("Number of living cells in row %d: %d", row, 
				rowCount(row));
		System.out.println();
	}

	// Prints the total number of living cells in a certain column
	public void printColCount(int col) {
		System.out.printf("Number of living cells in column %d: %d", col,
				colCount(col));
		System.out.println();
	}
	
	//Prints the total number of living cells on the board
	public void printTotalCount() {
		System.out.printf("Number of living cells in total: %d", 
				totalCount());
		System.out.println();
	}
	
	//Gets current generation
	public int getGeneration() {
		return generation;
	}
	
	//Adds generation listener to list of gen listeners
	public void addGenerationListener(GenerationListener l) {
		genLists.add(l);
	}
	
	//Removes gen listener from the list
	public void removeGenerationListener(GenerationListener l) {
		genLists.remove(l);
	}
	
	//Sets the generation and calls generationChanged on each listener
	public void setGeneration(int gen) {
		generation = gen;
		for(int i = 0; i < genLists.size(); i++) {
			genLists.get(i).generationChanged(getGeneration(), gen);
		}
	}
}
