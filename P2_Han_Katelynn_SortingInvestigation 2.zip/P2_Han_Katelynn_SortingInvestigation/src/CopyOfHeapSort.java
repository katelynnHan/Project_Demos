import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class CopyOfHeapSort {
	static int steps;

	public static void main(String[] args) {

		int[] arr = new int[400];

		Random rand = new Random();

		for (int i = 0; i < 400; i++) {
			arr[i] = rand.nextInt(100) + 1;
		}
		
		bubbleSortBack(arr); 

		System.out.println("Before: " + Arrays.toString(arr));
		long startTime = System.currentTimeMillis();
		mergeSort(arr, 0, arr.length - 1);
		//bubbleSort(arr);
		//heapSort(arr);
		System.out.println("After: " + Arrays.toString(arr));
		long endTime = System.currentTimeMillis();
		System.out.println("Time taken: " + (endTime - startTime) + "ms");

		System.out.println("Steps taken: " + steps);
	}

	//Ascending order
	public static void heapSort(int[] arr) {
		steps++;
		if (arr.length > 0) { // > operator
			steps++;
			buildMaxHeap(arr); // method
		}

		steps += 3;
		for (int i = arr.length - 1; i >= 0; i--) { // var, -, >=
			steps += 4; // >=, --
			swap(arr, 0, i); // method
			heapify(arr, 0, i - 1); // method, -
		}
	}

	public static void swap(int[] arr, int i, int j) {
		steps += 7;
		int temp = arr[i]; // var, [i]
		arr[i] = arr[j]; // var, [i], [j]
		arr[j] = temp; // var, [j]
	}

	public static void buildMaxHeap(int[] arr) {
		steps += 4;
		for (int i = arr.length / 2 - 1; i >= 0; i--) { // var, /2, -, >=
			// >=, --
			steps += 4;
			heapify(arr, i, arr.length - 1); // method, -1
		}
	}

	public static void heapify(int[] arr, int i, int partition) {
		steps += 2;
		int child1 = 0; // 2 methods
		int child2 = 0;

		steps += 3;
		if ((i * 2) + 1 <= partition) { // *, +, <=
			steps += 3;
			child1 = i * 2 + 1; // var, *, +
		} else {
			steps += 2;
			child1 = partition + 1; // var, +
		}

		steps += 3;
		if ((i * 2) + 2 <= partition) { // *, +, <=
			steps += 3;
			child2 = i * 2 + 2; // var, *, +
		} else {
			steps += 2;
			child2 = partition + 1; // var, +
		}

		steps++;
		int largestChild = i; // var

		steps += 5;
		if (child2 <= partition && child1 <= partition) { // <=, &&, <=
			steps += 5;
			largestChild = (arr[child1] >= arr[child2]) ? // =, [], >=, [], ?
					child1 : child2;
		} else if (child2 <= partition) { // <=
			steps++;
			largestChild = child2; // var
		} else if (child1 <= partition) { // <=
			steps++;
			largestChild = child1; // var
		}

		steps++;
		int largest = i; // var

		steps += 4;
		if (largestChild <= partition && arr[largestChild] > arr[i]) {
			// <=, &&, [], >
			steps++;
			largest = largestChild; // var
		}

		steps++;
		if (largest != i) { // !=
			steps += 2;
			swap(arr, largest, i); // method
			heapify(arr, largest, partition); // method
		}
	}

	// Ascending Order
	public static void mergeSort(int[] a, int first, int last) {
		steps += 2; // (steps for the if statements)
		steps += 2;

		if (last - first == 0) { // - operator, == operator

		} else if (last - first == 1) { // - operator, == operator
			steps += 4;
			if (a[first] > a[last]) { // get method,
				// compareTo method, get method, > operator

				steps += 2;
				swap(a, first, last);
			}
		} else { // recursion, divide into two halves
			steps += 3;
			int midpoint = (first + last) / 2; // variable assign, + operator,
			// divide operator

			steps++;
			mergeSort(a, first, midpoint); // mergeSort method

			steps += 2;
			mergeSort(a, midpoint + 1, last); // mergeSort method, + operator

			steps++;
			merge(a, first, midpoint, last); // merge method
		}
	}

	public static void merge(int[] a, int first, int mid, int last) {
		steps++; // var i assignment
		int i = first; // counter for the first sublist

		steps += 2; // var j assignment, + operator
		int j = mid + 1; // counter for the second sublist

		steps += 2;
		ArrayList<Comparable> temp = new ArrayList<Comparable>(); // var temp
		// asignment, arraylist constructor

		steps += 3;
		while (i <= mid || j <= last) { // <= operator, || operator, <= operator
			// steps for the if statements
			steps++;
			steps++;
			steps += 4;
			steps += 4;

			if (i > mid) { // > operator
				steps += 3;
				temp.add(a[j]); // add method, get method
				j++; // ++ operator
			} else if (j > last) { // > operator
				steps += 3;
				temp.add(a[i]); // add method, get method
				i++;
			} else if (a[i] < a[j]) { // get method,
				// compareTo method, get method, < operator

				steps += 3;
				temp.add(a[i]); // add method, get method
				i++; // ++ operator
			} else if (a[j] <= a[i]) { // get method,
				// compareTo method, get method, <= method

				steps += 3;
				temp.add(a[j]); // add method, get method
				j++; // ++ operator
			}
		}

		steps += 4;
		for (int l = first; l < last; l++) { // var l assignment, size
			// method, - method, >= operator

			steps += 2;
			
			a[l] = (int)(temp.get(1));
		}

	}

	// bubble smallest elements to the right
	public static void bubbleSort(int[] arr) {
		steps += 3;
		for (int stop = arr.length - 2; stop >= 0; stop--) { //var, -2, >=
			//>=, --
			steps += 2;
			
			steps += 2;
			for (int i = 0; i <= stop; i++) { //=, <=
				steps += 2;
				
				steps += 4;
				if (arr[i + 1] < arr[i]) { //[], i + 1, >, []
					
					steps += 3;
					int temp = arr[i + 1]; //=, [], +

					steps += 4;
					arr[i + 1] = arr[i];  //[], +, =, []
					steps += 2;
					arr[i] = temp; //[], =

				}
			}
		}
	}
	
	// bubble smallest elements to the right
		public static void bubbleSortBack(int[] arr) {
			steps += 3;
			for (int stop = arr.length - 2; stop >= 0; stop--) { //var, -2, >=
				//>=, --
				steps += 2;
				
				steps += 2;
				for (int i = 0; i <= stop; i++) { //=, <=
					steps += 2;
					
					steps += 4;
					if (arr[i + 1] > arr[i]) { //[], i + 1, >, []
						
						steps += 3;
						int temp = arr[i + 1]; //=, [], +

						steps += 4;
						arr[i + 1] = arr[i];  //[], +, =, []
						steps += 2;
						arr[i] = temp; //[], =

					}
				}
			}
		}

}
